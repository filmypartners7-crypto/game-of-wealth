import re
W='/scratch/work'
css=open(f'{W}/styles.css').read()+open(f'{W}/popups.css').read(); body=open(f'{W}/body.html').read()
engine=open(f'{W}/engine.js').read().replace("if (typeof module !== 'undefined' && module.exports) module.exports = Engine;\n","")
bots=open(f'{W}/bots.js').read().replace("if (typeof module !== 'undefined' && module.exports) module.exports = Bots;\n","")
app=open(f'{W}/app.js').read()
html=f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#8fd8f7">
<meta name="color-scheme" content="light">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Wealth">
<title>Game of Wealth</title>
<link rel="manifest" href="manifest.json">
<link rel="icon" href="icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="icon.svg">
<style>
html,body{{margin:0;padding:0;overflow:hidden;height:100%;background:#e2a6cf}}
html{{background:url('assets/game/table-empty.webp') center center/cover no-repeat fixed}}
body{{background:transparent}}
{css}
</style>
</head>
<body>
{body}
<script>
{engine}
{bots}
{app}
</script>
<script>
if ('serviceWorker' in navigator) {{
  var __reloaded = false;
  navigator.serviceWorker.addEventListener('controllerchange', function () {{
    if (!__reloaded) {{ __reloaded = true; location.reload(); }}
  }});
  window.addEventListener('load', function () {{
    navigator.serviceWorker.register('./sw.js', {{ updateViaCache: 'none' }}).then(function (reg) {{
      reg.update();
      setInterval(function () {{ reg.update(); }}, 60000);
    }}).catch(function () {{}});
  }});
}}
</script>
</body>
</html>
"""
V = '100'
html = re.sub(r"(assets/[A-Za-z0-9_\-./]+\.(?:webp|png|jpg|svg|woff2))", lambda m: m.group(1) + '?v=' + V, html)
html = html.replace("<body", "<body data-build=\"v" + V + "\"", 1)
html = html.replace("navigator.serviceWorker.register('./sw.js')", "navigator.serviceWorker.register('./sw.js?v=" + V + "')")
open(f'{W}/deploy/index.html','w').write(html)
print('ok', len(html))

# keep the no-cache /v2 copy in sync with every build
import shutil, re as _re
_v2 = f'{W}/deploy/v2'
shutil.rmtree(f'{_v2}/assets', ignore_errors=True)
shutil.copytree(f'{W}/deploy/assets', f'{_v2}/assets')
_v2html = _re.sub(r"if \('serviceWorker' in navigator\) \{.*?\n\}\n", "", html, flags=_re.S)
_v2html = _v2html.replace('<link rel="manifest" href="manifest.webmanifest">', '')
open(f'{_v2}/index.html', 'w').write(_v2html)
print('v2 synced')
