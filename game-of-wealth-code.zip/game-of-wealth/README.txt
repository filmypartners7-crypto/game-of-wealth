GAME OF WEALTH — source package
================================
Build v100, commit 11ddd47. The layout editor has been removed.

SOURCE
  body.html      page markup (all screens)
  styles.css     all styling
  popups.css     popup styling (separate so table edits can't wipe it)
  app.js         UI + game flow
  engine.js      pure engine (bidding, hands, payouts, gold market)
  bots.js        bot bidding and card choice
  builddeploy.py rebuilds index.html from the files above

BUILT
  index.html     single-file game (CSS + JS inlined)
  v2/index.html  same build, no service worker
  assets/        every image, icon and font
  sw.js          service worker

RUN
  Open index.html in a browser — everything is relative, no server needed.
  Rebuild after edits:  python3 builddeploy.py
