/* ================= MINIMAL LAYOUT EDITOR (?edit=1) =================
   Tap an item to select it, then nudge with arrows (0.5% of the stage) and
   size with −/+ (1%). Values live in one LAYOUT object (x, y, w in %) which is
   saved to localStorage and applied over the game's own positions.
   No dragging, no resize handles. Only loads with ?edit=1. */
(function () {
  if (!/[?&]edit=1/.test(location.search)) return;

  const KEY = 'gow-layout';
  let L = { seats: {}, deck: null, discard: null, play: {}, hand: null, __locked: false };
  try { Object.assign(L, JSON.parse(localStorage.getItem(KEY) || 'null') || {}); } catch (e) {}
  const save = function () { try { localStorage.setItem(KEY, JSON.stringify(L)); } catch (e) {} };
  window.__LAYOUT = L;

  let SEL = null;                       // { el, kind, key }
  const pct = function (v) { return v.toFixed(2) + '%'; };

  function stage() { return document.getElementById('stage'); }
  function srect() { const s = stage(); return s ? s.getBoundingClientRect() : { width: 1, height: 1 }; }

  /* ---------- apply saved values ---------- */
  function apply() {
    const sr = srect(); if (!sr.width) return;
    Object.keys(L.seats || {}).forEach(function (name) {
      const b = seatBox(name); if (!b) return;
      const o = L.seats[name];
      if (o.x != null) b.style.left = pct(o.x);
      if (o.y != null) b.style.top = pct(o.y);
      const img = b.querySelector('.tb-char');
      if (img && o.w) img.style.width = pct(o.w);
    });
    const piles = document.querySelectorAll('#tbPiles .tb-pilecard');
    const disc = document.querySelector('#tbPiles .tb-empty') || piles[3];
    if (L.deck && piles[0]) { piles[0].style.left = pct(L.deck.x); piles[0].style.top = pct(L.deck.y); }
    if (L.discard && disc) { disc.style.left = pct(L.discard.x); disc.style.top = pct(L.discard.y); }
    Object.keys(L.play || {}).forEach(function (pid) {
      const el = document.querySelector('.tb-played[data-pid="' + pid + '"]'); if (!el) return;
      const o = L.play[pid];
      if (o.x != null) el.style.left = pct(o.x);
      if (o.y != null) el.style.top = pct(o.y);
      if (o.w) el.style.width = pct(o.w);
    });
    if (L.hand && L.hand.y != null) {
      const hs = document.getElementById('handStrip');
      if (hs) hs.style.marginTop = L.hand.y + 'px';
    }
  }

  function seatBox(name) {
    return Array.prototype.filter.call(document.querySelectorAll('.tb-seatbox'), function (b) {
      const n = b.querySelector('.pname'); return n && n.textContent === name;
    })[0];
  }

  /* ---------- what can be selected ---------- */
  function targets() {
    const out = [];
    document.querySelectorAll('.tb-seatbox').forEach(function (b) {
      const n = b.querySelector('.pname');
      if (n) out.push({ el: b, kind: 'seat', key: n.textContent, label: n.textContent });
    });
    const piles = document.querySelectorAll('#tbPiles .tb-pilecard');
    const disc = document.querySelector('#tbPiles .tb-empty') || piles[3];
    if (piles[0]) out.push({ el: piles[0], kind: 'deck', key: 'deck', label: 'Deck' });
    if (disc) out.push({ el: disc, kind: 'discard', key: 'discard', label: 'Discard' });
    document.querySelectorAll('.tb-played').forEach(function (el) {
      out.push({ el: el, kind: 'play', key: el.dataset.pid, label: 'Played: ' + (el.dataset.pid || '') });
    });
    const hs = document.getElementById('handStrip');
    if (hs) out.push({ el: hs, kind: 'hand', key: 'hand', label: 'Hand strip' });
    return out;
  }

  function val(kind, key, f) {
    if (kind === 'seat') return (L.seats[key] || {})[f];
    if (kind === 'play') return (L.play[key] || {})[f];
    if (kind === 'hand') return (L.hand || {})[f];
    return (L[key] || {})[f];
  }
  function setVal(kind, key, f, v) {
    if (kind === 'seat') { L.seats[key] = Object.assign(L.seats[key] || {}, {}); L.seats[key][f] = v; }
    else if (kind === 'play') { L.play[key] = Object.assign(L.play[key] || {}, {}); L.play[key][f] = v; }
    else if (kind === 'hand') { L.hand = L.hand || {}; L.hand[f] = v; }
    else { L[key] = Object.assign(L[key] || {}, {}); L[key][f] = v; }
    save();
  }

  /* current value, seeded from where the element actually is */
  function current(f) {
    if (!SEL) return 0;
    const v = val(SEL.kind, SEL.key, f);
    if (v != null) return v;
    const sr = srect(), r = SEL.el.getBoundingClientRect();
    if (f === 'x') return ((r.left + r.width / 2 - sr.left) / sr.width) * 100;
    if (f === 'y') return ((r.bottom - sr.top) / sr.height) * 100;
    if (f === 'w') return (r.width / sr.width) * 100;
    return (r.height / sr.height) * 100;
  }

  function move(dx, dy) {
    if (!SEL) return;
    const nx = current('x') + dx, ny = current('y') + dy;
    if (isFinite(nx)) setVal(SEL.kind, SEL.key, 'x', Math.round(nx * 100) / 100);
    if (isFinite(ny)) setVal(SEL.kind, SEL.key, 'y', Math.round(ny * 100) / 100);
    apply(); paint();
  }
  function size(d) {
    if (!SEL) return;
    const nw = current('w') + d;
    if (isFinite(nw)) setVal(SEL.kind, SEL.key, 'w', Math.round(nw * 100) / 100);
    apply(); paint();
  }

  /* ---------- UI ---------- */
  let panel = null;
  function build() {
    if (panel) return;
    panel = document.createElement('div');
    panel.id = 'edPanel';
    panel.innerHTML =
      '<div class="edTop"><span id="edName">tap an item</span>' +
      '<button id="edCopy">Copy layout</button><button id="edReset">Reset</button></div>' +
      '<div class="edPad">' +
      '<button class="edB" data-mv="0,-1">↑</button>' +
      '<button class="edB" data-mv="-1,0">←</button>' +
      '<button class="edB" data-mv="1,0">→</button>' +
      '<button class="edB" data-mv="0,1">↓</button>' +
      '<span class="edSep"></span>' +
      '<button class="edB" data-sz="-1">−</button>' +
      '<button class="edB" data-sz="1">+</button>' +
      '</div>';
    document.body.appendChild(panel);
    document.body.classList.add('editing');

    panel.querySelectorAll('[data-mv]').forEach(function (b) {
      const [dx, dy] = b.dataset.mv.split(',').map(Number);
      hold(b, function () { move(dx * 0.5, dy * 0.5); });
    });
    panel.querySelectorAll('[data-sz]').forEach(function (b) {
      const d = Number(b.dataset.sz);
      hold(b, function () { size(d); });
    });
    panel.querySelector('#edReset').onclick = function () {
      localStorage.removeItem(KEY); location.reload();
    };
    panel.querySelector('#edCopy').onclick = function () {
      const json = JSON.stringify(L, null, 2);
      if (navigator.clipboard) navigator.clipboard.writeText(json).catch(function () {});
      const ta = document.createElement('textarea');
      ta.value = json;
      ta.style.cssText = 'position:fixed;inset:6% 4% 30% 4%;z-index:99999;font:11px monospace;padding:8px;border-radius:10px';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.onclick = function () { ta.remove(); };
    };
  }
  function hold(btn, fn) {
    let t = null, iv = null;
    const start = function (e) {
      e.preventDefault(); fn();
      t = setTimeout(function () { iv = setInterval(fn, 90); }, 350);
    };
    const end = function () { clearTimeout(t); clearInterval(iv); };
    btn.addEventListener('pointerdown', start);
    btn.addEventListener('pointerup', end);
    btn.addEventListener('pointerleave', end);
    btn.addEventListener('pointercancel', end);
  }
  function paint() {
    if (!panel) return;
    panel.querySelector('#edName').textContent = SEL ? SEL.label : 'tap an item';
    document.querySelectorAll('.edSel').forEach(function (x) { x.classList.remove('edSel'); });
    if (SEL) SEL.el.classList.add('edSel');
  }

  /* ---------- selection ---------- */
  function pick(ev) {
    const t = targets().filter(function (o) { return o.el === ev.currentTarget; })[0];
    if (!t) return;
    ev.preventDefault(); ev.stopPropagation();
    SEL = t; paint();
  }
  function attach() {
    targets().forEach(function (t) {
      if (t.el.dataset.edsel) return;
      t.el.dataset.edsel = '1';
      t.el.style.touchAction = 'none';
      t.el.addEventListener('pointerdown', pick);
    });
  }

  function tableVisible() {
    const t = document.getElementById('tableScreen');
    if (!t) return false;
    const st = getComputedStyle(t);
    return st.display !== 'none' && !t.hidden && st.visibility !== 'hidden';
  }
  function loop() {
    if (!panel) return;
    const on = tableVisible();
    panel.style.display = on ? 'flex' : 'none';
    document.body.classList.toggle('editing', on);
    if (on) { apply(); attach(); paint(); }
  }
  window.addEventListener('load', function () { build(); loop(); });
  document.addEventListener('DOMContentLoaded', function () { build(); loop(); });
  setInterval(loop, 500);
})();
