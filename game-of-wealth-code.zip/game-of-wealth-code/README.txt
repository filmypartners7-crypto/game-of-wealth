GAME OF WEALTH — source package
================================
Built: build v98, commit b8dfa91

SOURCE FILES
  body.html      page markup (all screens)
  styles.css     all styling
  popups.css     popup styling (kept separate so table edits can't wipe it)
  app.js         UI + game flow
  engine.js      pure game engine (bidding, hands, payouts, gold market)
  bots.js        bot bidding / card choice
  editor.js      layout editor (?edit=1 only)
  builddeploy.py builds index.html from the files above

BUILT OUTPUT
  index.html     the single-file game (all CSS + JS inlined)
  v2/index.html  same build with no service worker
  assets/        every image, font and icon
  sw.js          service worker
  manifest.webmanifest

RUNNING LOCALLY
  Open index.html in a browser. Everything is relative, so no server needed.
  To rebuild after editing: python3 builddeploy.py

LAYOUT EDITOR
  Add ?edit=1 to the URL. Tap an item on the table, then use the arrows to
  move (0.5% per tap) and -/+ to resize (1%). Copy layout exports the JSON.
