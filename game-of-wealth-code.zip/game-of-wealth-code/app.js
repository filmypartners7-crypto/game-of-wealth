/* =====================================================================
   UI LAYER — oval table, tabbed action panel, bottom nav.
   Reads engine state, renders, sends intents back. No rules live here.
   ===================================================================== */
(function () {
  'use strict';
  const E = Engine, B = Bots;
  const $ = function (id) { return document.getElementById(id); };
  const fmt = function (n) { return '\u20B9' + Math.round(n).toLocaleString('en-IN'); };
  const esc = function (t) {
    return String(t).replace(/[&<>"]/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c];
    });
  };

  let S = null;
  const UI = {
    mode: 'bots', diff: 'normal', players: 4, cash: 2000,
    gateDone: null, gateShowing: null, panelKey: null, sheetKind: null,
    handTimer: null, botTimer: null, selected: null, saved: null,
    bidValue: 100, handsShown: false, revealShown: false, sheetOpen: false,
    lastActor: null, tab: 'gold', tabStep: null, goldMode: 'buy', goldQty: 1,
    loanLender: 'bank', loanAmount: 400, priceRound: 0, priceTimer: null
  };

  /* ---------------- screens ---------------- */
  const PROFILE = { name: 'Player', level: 1, xp: 0, xpMax: 800, cash: 2000, rix: 0 };

  function showScreen(name) {
    $('splashScreen').hidden = name !== 'splash';
    $('homeScreen').hidden = name !== 'home';
    const ts = $('tableSelectScreen');
    if (ts) ts.hidden = name !== 'tableSelect';
    const lb = $('lobbyScreen');
    if (lb) lb.hidden = name !== 'lobby';
    const tbs = $('tableScreen');
    if (tbs) tbs.hidden = name !== 'table';
    $('menuScreen').hidden = name !== 'menu';
    $('gameScreen').hidden = name !== 'game';
  }

  function renderHome() {
    $('homeName').textContent = PROFILE.name;
    $('homeLevel').textContent = 'Lv ' + PROFILE.level;
    $('homeXp').textContent = PROFILE.xp + ' / ' + PROFILE.xpMax;
    $('homeCash').textContent = Math.round(PROFILE.cash).toLocaleString('en-IN');
    $('homeRix').textContent = PROFILE.rix;
    fitHome();
  }

  function fitHome() {
    const sx = window.innerWidth / 941, sy = window.innerHeight / 1672;
    ['hsStage', 'tsStage'].forEach(function (id) {
      const st = $(id);
      if (st) st.style.transform = 'scale(' + sx + ',' + sy + ')';
    });
  }

  function playEntrance() {
    const st = $('hsStage');
    if (!st) return;
    const items = st.querySelectorAll('.hs-txt, .hs-tap');
    items.forEach(function (el, i) { el.style.setProperty('--d', (i * 0.06).toFixed(2) + 's'); });
    st.classList.remove('hs-in');
    void st.offsetWidth;
    st.classList.add('hs-in');
  }

  /* ---- toast + tap sound ---- */
  let toastTimer = null;
  function toast(msg) {
    let el = document.getElementById('toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'toast';
      el.className = 'toast';
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 1600);
  }

  let actx = null;
  function playTap() {
    try {
      if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      const t = actx.currentTime;
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = 'triangle';
      o.frequency.setValueAtTime(780, t);
      o.frequency.exponentialRampToValueAtTime(420, t + 0.07);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.05, t + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
      o.connect(g); g.connect(actx.destination);
      o.start(t); o.stop(t + 0.1);
    } catch (e) { /* audio unavailable */ }
  }

  function spawnSparkles() {
    const wrap = $('sparkles');
    if (!wrap) return;
    wrap.innerHTML = '';
    for (let i = 0; i < 7; i++) {
      const el = document.createElement('span');
      el.className = 'spark';
      el.style.left = (300 + Math.random() * 340) + 'px';
      el.style.top = (140 + Math.random() * 560) + 'px';
      const sc = 0.6 + Math.random() * 0.8;
      el.style.transform = 'scale(' + sc.toFixed(2) + ')';
      el.style.animationDelay = (-Math.random() * 2.6).toFixed(2) + 's';
      el.style.animationDuration = (2.2 + Math.random() * 1.4).toFixed(2) + 's';
      wrap.appendChild(el);
    }
  }

  function goHome() {
    renderHome();
    spawnSparkles();
    showScreen('home');
    playEntrance();
  }

  /* ---------------- sheet ---------------- */
  function openSheet(html, cls, kind) {
    $('sheet').className = 'sheet ' + (cls || '');
    $('sheet').innerHTML = html;
    $('overlay').hidden = false;
    UI.sheetOpen = true;
    UI.sheetKind = kind || cls || 'generic';
    requestAnimationFrame(function () { $('overlay').classList.add('in'); });
  }
  function closeSheet() {
    $('overlay').classList.remove('in');
    UI.sheetOpen = false;
    UI.sheetKind = null;
    setTimeout(function () {
      if (!UI.sheetOpen) { $('overlay').hidden = true; $('sheet').innerHTML = ''; }
    }, 190);
  }
  const sheetOpen = function () { return UI.sheetOpen; };

  /* ---------------- game start ---------------- */
  function startGame() {
    const list = [];
    if (UI.mode === 'bots') {
      list.push({ name: 'You', isBot: false });
      for (let i = 1; i < UI.players; i++) list.push({ name: 'Bot ' + i, isBot: true, bot: UI.diff });
    } else {
      for (let i = 0; i < UI.players; i++) list.push({ name: 'Player ' + (i + 1), isBot: false });
    }
    clearTimeout(UI.botTimer); UI.botTimer = null;
    S = E.newGame({ players: list, startingCash: UI.cash });
    resetTurnUI();
    showScreen('game');
    render();
  }

  function resetTurnUI() {
    UI.gateDone = null; UI.gateShowing = null; UI.panelKey = null;
    UI.selected = null; UI.handsShown = false; UI.revealShown = false;
    UI.tab = 'gold'; UI.tabStep = null; UI.goldMode = 'buy'; UI.goldQty = 1;
    UI.loanLender = 'bank'; UI.loanAmount = 400;
    UI.priceRound = 0;
    clearTimeout(UI.handTimer); UI.handTimer = null;
    clearTimeout(UI.priceTimer); UI.priceTimer = null;
    closeSheet();
  }

  /* ---------------- viewer ---------------- */
  function viewerId() {
    if (!S) return null;
    if (UI.mode === 'bots') return 'p0';
    if (UI.gateShowing) return null;
    return S.actor || UI.lastActor;
  }
  function privatePhase(s) {
    if (s.phase === 'bid' || s.phase === 'select') return true;
    if (s.step === 'gold' || s.step === 'cards' || s.step === 'loanRequest' ||
      s.step === 'loanOffer' || s.step === 'finalSell') return true;
    return false;
  }
  function gateKey(s, p) {
    return p.id + '|' + s.phase + '|' + (s.step || '') + '|' + s.round + '|' + s.matchIndex;
  }

  /* ---------------- tick ---------------- */
  function tick() {
    if (!S) return;
    const s = S;

    if (s.phase === 'payout') {
      if (!UI.revealShown) { UI.revealShown = true; showReveal(); }
      return;
    }
    if (s.phase === 'handReveal') {
      if (!UI.handsShown) { UI.handsShown = true; showHands(); }
      armHandReveal();
      return;
    }
    if (s.phase === 'roundEnd') {
      if (UI.sheetKind !== 'round') { UI.sheetKind = 'round'; showRoundEnd(); }
      return;
    }
    if (s.phase === 'gameEnd') {
      if (UI.sheetKind !== 'results') { UI.sheetKind = 'results'; showResults(); }
      return;
    }

    maybePriceSheet();

    const p = s.actor ? E.byId(s, s.actor) : null;
    if (!p) return;

    if (UI.mode === 'local' && !p.isBot && privatePhase(s)) {
      const k = gateKey(s, p);
      if (UI.gateDone !== k) {
        if (UI.gateShowing !== k) { UI.gateShowing = k; showGate(p, k); }
        return;
      }
    }

    if (p.isBot && !UI.botTimer) {
      UI.botTimer = setTimeout(function () { UI.botTimer = null; botAct(); }, 420);
    }
  }

  function maybePriceSheet() {
    const s = S;
    if (s.round <= 1 || s.phase !== 'roundStart') return;
    if (UI.priceRound === s.round) return;
    UI.priceRound = s.round;
    showPricePop();
  }

  function armHandReveal() {
    if (UI.handTimer) return;
    UI.handTimer = setTimeout(function () {
      UI.handTimer = null;
      if (S && S.phase === 'handReveal') { UI.handsShown = false; closeSheet(); E.revealDone(S); render(); }
    }, 4500);
  }
  function continueHands() {
    clearTimeout(UI.handTimer); UI.handTimer = null;
    UI.handsShown = false;
    closeSheet();
    if (S && S.phase === 'handReveal') { E.revealDone(S); render(); }
  }

  /* ---------------- bots ---------------- */
  function botAct() {
    if (!S) return;
    const s = S;
    const p = s.actor ? E.byId(s, s.actor) : null;
    if (!p) return;

    if (s.step === 'gold') {
      const mv = B.goldMove(s, p);
      if (mv) {
        if (mv.buy) E.buyGold(s, p.id, Math.min(mv.buy, Math.floor(p.cash / s.goldPrice)));
        if (mv.sell) E.sellGold(s, p.id, Math.min(mv.sell, p.gold));
      }
      E.endGoldTurn(s);
    } else if (s.step === 'cards') {
      const wish = B.cardWish(s, p);
      if (wish) E.buyDiscardCard(s, p.id, wish.id);
      E.endCardTurn(s);
    } else if (s.step === 'loanRequest') {
      const d = B.loanRequest(s, p);
      if (d.decline) E.declineLoan(s, p.id);
      else if (!E.requestLoan(s, p.id, d.amount, d.lender)) E.declineLoan(s, p.id);
    } else if (s.step === 'loanOffer') {
      const lp = s.loanPending;
      const ok = lp ? B.loanOffer(s, p, lp.borrower, lp.amount) : false;
      E.answerLoanOffer(s, p.id, ok);
    } else if (s.phase === 'bid') {
      const v = B.bid(s, p);
      if (v == null || !E.placeBid(s, p.id, v)) E.placeBid(s, p.id, Math.max(E.MIN_BID, Math.min(p.cash, E.MIN_BID)));
    } else if (s.phase === 'select') {
      const c = B.pick(s, p);
      if (c == null || !E.playCard(s, p.id, c)) {
        const any = p.hand[0];
        if (any) E.playCard(s, p.id, any.id);
      }
    } else if (s.step === 'finalSell') {
      E.sellFinal(s, p.id, B.finalSale(s, p));
    }
    render();
  }

  /* ---------------- render ---------------- */
  function render() {
    if (!S) return;
    const s = S;
    if (UI.lastActor !== s.actor && s.actor) UI.lastActor = s.actor;
    if (UI.selected && !handHas(UI.selected)) UI.selected = null;

    $('roundLabel').textContent = 'Round ' + s.round + ' \u00B7 Match ' +
      Math.min(Math.max(s.matchIndex, 0), s.matchesThisRound || 0) + '/' + (s.matchesThisRound || 0);

    renderGold();
    renderSeats();
    renderPiles();
    renderYou();
    renderHand();
    renderPanel();
    renderNav();
    tick();
  }

  function handHas(id) {
    const vid = viewerId();
    const p = vid ? E.byId(S, vid) : null;
    return !!(p && p.hand.some(function (c) { return c.id === id; }));
  }

  /* ---------------- gold widget ---------------- */
  function renderGold() {
    const s = S;
    const hist = s.priceHistory;
    $('goldPrice').textContent = Math.round(s.goldPrice).toLocaleString('en-IN');
    const prev = hist.length > 1 ? hist[hist.length - 2].price : s.goldPrice;
    const d = s.goldPrice - prev;
    const el = $('goldDelta');
    if (d > 0) { el.textContent = '\u25B2' + Math.abs(d).toLocaleString('en-IN'); el.className = 'delta up'; }
    else if (d < 0) { el.textContent = '\u25BC' + Math.abs(d).toLocaleString('en-IN'); el.className = 'delta down'; }
    else { el.textContent = '\u25AC'; el.className = 'delta flat'; }

    const data = hist.slice(-18).map(function (x) { return x.price; });
    const svg = $('goldChart');
    if (data.length < 2) {
      svg.innerHTML = '<line x1="0" y1="12" x2="100" y2="12" stroke="#3a4a41" stroke-width="1" stroke-dasharray="3 3"/>';
      return;
    }
    const w = 100, h = 22;
    const mn = Math.min.apply(null, data), mx = Math.max.apply(null, data);
    const span = Math.max(20, mx - mn);
    const pts = data.map(function (v, i) {
      const px = (i / (data.length - 1)) * w;
      const py = (h - 3) - ((v - mn) / span) * (h - 8);
      return px.toFixed(1) + ',' + py.toFixed(1);
    });
    const up = data[data.length - 1] >= data[0];
    const col = up ? '#3ddc84' : '#ff6b6b';
    svg.innerHTML = '<polyline points="' + pts.join(' ') + '" fill="none" stroke="' + col +
      '" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/>' +
      '<circle cx="' + pts[pts.length - 1].split(',')[0] + '" cy="' + pts[pts.length - 1].split(',')[1] +
      '" r="1.8" fill="' + col + '"/>';
  }

  /* ---------------- oval seats ---------------- */
  function seatAngles(k) {
    if (k <= 0) return [];
    if (k === 1) return [270];
    const out = [];
    for (let i = 0; i < k; i++) out.push(150 + i * (240 / (k - 1)));
    return out;
  }

  function avatarLetter(name) {
    const m = String(name).match(/(\d+)\s*$/);
    if (m) return m[1];
    return String(name).trim().charAt(0).toUpperCase();
  }

  function renderSeats() {
    const s = S;
    const vid = viewerId();
    const me = vid ? E.byId(s, vid) : null;
    const others = s.players.filter(function (p) { return !me || p.id !== me.id; });
    const angles = seatAngles(others.length);
    const reveal = s.phase === 'handReveal' || s.phase === 'payout';
    const liveMatch = s.phase === 'bid' || s.phase === 'select' || s.phase === 'handReveal' || s.phase === 'payout';
    const inMatch = s.matchPlayers || [];

    $('seats').dataset.n = others.length;
    $('seats').innerHTML = others.map(function (p, i) {
      const a = angles[i] * Math.PI / 180;
      const x = 50 + 30 * Math.cos(a);
      const y = 50 + 29 * Math.sin(a);
      const cls = ['seat'];
      if (p.eliminated) cls.push('out');
      if (s.actor === p.id) cls.push('active');

      let chip = '';
      const bid = s.bids[p.id];
      const lm = s.lastMatch;
      if (lm && lm.bids && lm.bids[p.id] != null && s.phase === 'payout') {
        chip = '<span class="bidchip ' + (lm.winner === p.id ? 'win' : 'amount') + '">' + fmt(lm.bids[p.id]) + '</span>';
      } else if (bid != null && liveMatch) {
        chip = '<span class="bidchip locked">Bid Locked</span>';
      } else if (s.phase === 'bid' && inMatch.indexOf(p.id) >= 0 && s.actor === p.id) {
        chip = '<span class="bidchip">bidding\u2026</span>';
      }
      const debt = (s.loans || []).find(function (l) { return l.borrowerId === p.id; });
      if (!chip && debt) chip = '<span class="bidchip debt">owes ' + fmt(debt.amount) + '</span>';

      const low = p.cash < E.MIN_BID;

      let hue = 0;
      for (let ci = 0; ci < p.name.length; ci++) hue = (hue * 31 + p.name.charCodeAt(ci)) % 360;

      return '<div class="' + cls.join(' ') + '" style="left:' + x.toFixed(2) + '%;top:' + y.toFixed(2) + '%">' +
        '<img class="avatar" src="assets/a' + ((p.seat % 5) + 1) + '.webp" alt="">' +
        '<div class="plate">' +
        '<span class="nm">' + esc(p.name) + '</span>' +
        '<span class="money"><span class="cash' + (low && !p.eliminated ? ' low' : '') + '">' + fmt(p.cash) + '</span>' +
        '<span class="gold"><i></i>' + p.gold + '</span></span>' +
        (p.eliminated ? '<span class="handn">out</span>' : '<span class="handn">' + p.hand.length + ' cards</span>') +
        '</div>' +
        (chip || '<span class="bidchip" style="visibility:hidden">.</span>') +
        '</div>';
    }).join('');
  }

  function renderPiles() {
    const s = S;
    $('deckCount').textContent = s.deck.length;
    $('discardCount').textContent = s.discard.length;
    $('bankCash').textContent = fmt(s.bank.cash);
    $('deckPile').classList.toggle('empty', s.deck.length === 0);
  }

  /* ---------------- your area ---------------- */
  function renderYou() {
    const s = S;
    const vid = viewerId();
    const p = vid ? E.byId(s, vid) : null;
    const cash = $('youCash'), gold = $('youGold');
    if (!p) {
      $('youName').textContent = 'Pass';
      cash.textContent = '\u2014';
      gold.textContent = '\u2014';
      $('handCount').textContent = '';
      return;
    }
    $('youName').textContent = p.eliminated ? 'Out' : (p.name === 'You' ? 'You' : p.name);
    cash.textContent = fmt(p.cash);
    gold.textContent = p.gold;
    cash.classList.toggle('low', p.cash < E.MIN_BID && !p.eliminated);
    $('handCount').textContent = p.eliminated ? '' : p.hand.length + ' / ' + E.HAND_LIMIT;

    const banner = $('phaseBanner');
    banner.textContent = bannerText(s);
    banner.className = 'phasebar' + (s.phase === 'bid' || s.phase === 'select' ? ' hot'
      : s.phase === 'roundStart' ? ' gold' : '');
  }

  function bannerText(s) {
    if (s.phase === 'roundStart') {
      if (s.step === 'gold') return 'Gold Market';
      if (s.step === 'cards') return 'Buy Cards';
      return 'Loans Due';
    }
    if (s.phase === 'bid') return 'Place Your Bid';
    if (s.phase === 'handReveal') return 'Hands Revealed';
    if (s.phase === 'select') return 'Pick a Card';
    if (s.phase === 'payout') return 'Reveal!';
    if (s.phase === 'roundEnd') return 'Round Complete';
    if (s.phase === 'finalSell') return 'Final Gold Sale';
    if (s.phase === 'gameEnd') return 'Game Over';
    return '';
  }

  /* ---------------- hand fan ---------------- */
  function renderHand() {
    const s = S;
    const vid = viewerId();
    const p = vid ? E.byId(s, vid) : null;
    const el = $('hand');
    if (!p || p.eliminated) {
      el.innerHTML = '';
      for (let i = 0; i < 5; i++) {
        const d = i - 2;
        const span = document.createElement('span');
        span.className = 'card ghost';
        span.style.cssText = 'left:50%;margin-left:-26px;transform:translateX(' + (d * 30) + 'px) translateY(' +
          (Math.abs(d) * Math.abs(d) * 2.2) + 'px) rotate(' + (d * 7) + 'deg);z-index:' + i;
        el.appendChild(span);
      }
      return;
    }
    const canPick = !p.isBot && s.phase === 'select' && s.actor === p.id;
    const n = p.hand.length;
    const mid = (n - 1) / 2;
    el.innerHTML = p.hand.map(function (c, i) {
      const d = i - mid;
      const sel = UI.selected === c.id;
      const rot = sel ? 0 : d * 7;
      const x = d * 30;
      const y = sel ? -22 : Math.abs(d) * Math.abs(d) * 2.2;
      const red = (c.s === 1 || c.s === 2) ? ' red' : '';
      return '<button class="card' + red + (canPick ? ' pickable' : '') + (sel ? ' sel' : '') +
        '" data-card="' + c.id + '" style="left:50%;margin-left:-26px;z-index:' + i +
        ';transform:translateX(' + x + 'px) translateY(' + y + 'px) rotate(' + rot + 'deg)">' +
        '<span class="r">' + E.RANK_LABEL[c.r] + '</span><span class="s">' + E.SUITS[c.s] + '</span></button>';
    }).join('');
  }

  /* ---------------- action panel ---------------- */
  function panelKey() {
    const s = S;
    return [s.phase, s.step || '', s.actor || '', s.round, s.matchIndex, s.queueIdx,
      UI.gateDone || '-', UI.tab, UI.goldMode, UI.goldQty, UI.selected || '-',
      s.discard.length, s.players.map(function (p) { return p.cash + '/' + p.gold; }).join(',')].join('|');
  }

  function renderPanel() {
    const s = S;
    const k = panelKey();
    if (k === UI.panelKey) return;
    UI.panelKey = k;
    const bar = $('actionbar');
    const p = s.actor ? E.byId(s, s.actor) : null;

    if (s.phase === 'payout' || s.phase === 'handReveal') {
      bar.innerHTML = '<div class="hint">' + (s.phase === 'payout' ? 'Reveal\u2026' : 'Hands revealed') + '</div>';
      return;
    }
    if (s.phase === 'gameEnd') { bar.innerHTML = '<div class="hint">Game over</div>'; return; }
    if (s.phase === 'roundEnd') { bar.innerHTML = '<div class="hint">Round complete</div>'; return; }
    if (!p) { bar.innerHTML = '<div class="hint">\u2026</div>'; return; }
    if (p.isBot) {
      bar.innerHTML = '<div class="hint"><span class="dotpulse"></span>' + esc(p.name) + ' is thinking\u2026</div>';
      return;
    }
    if (UI.mode === 'local' && UI.gateDone !== gateKey(s, p)) {
      bar.innerHTML = '<div class="hint">Pass the device to ' + esc(p.name) + '</div>';
      return;
    }

    if (s.phase === 'bid') return panelBid(bar, s, p);
    if (s.phase === 'select') return panelSelect(bar, s, p);
    if (s.phase === 'roundStart') return panelRoundStart(bar, s, p);
    if (s.step === 'finalSell') return panelFinal(bar, s, p);
    bar.innerHTML = '<div class="hint">\u2026</div>';
  }

  /* -- bid -- */
  function panelBid(bar, s, p) {
    const r = E.legalBidRange(s, p.id);
    UI.bidValue = Math.max(r.min, Math.min(r.max, UI.bidValue));
    const step = r.max > 4000 ? 50 : 10;
    bar.innerHTML =
      '<div class="bidrow"><span>Your bid</span><b id="bidVal">' + fmt(UI.bidValue) + '</b></div>' +
      '<input type="range" id="bidRange" min="' + r.min + '" max="' + r.max + '" step="' + step + '" value="' + UI.bidValue + '">' +
      '<div class="quick">' +
      '<button data-q="min" class="' + (UI.bidValue === r.min ? 'on' : '') + '"><span>MIN</span><small>(' + fmt(r.min) + ')</small></button>' +
      '<button data-q="2x" class="' + (UI.bidValue === Math.min(r.max, 200) ? 'on' : '') + '"><span>2\u00D7</span><small>(' + fmt(Math.min(r.max, 200)) + ')</small></button>' +
      '<button data-q="all" class="' + (UI.bidValue === r.max ? 'on' : '') + '"><span>ALL-IN</span><small>(' + fmt(r.max) + ')</small></button>' +
      '</div>' +
      '<button class="btn primary wide" id="btnBid">Bid ' + fmt(UI.bidValue) + '</button>';
    const range = $('bidRange'), val = $('bidVal'), btn = $('btnBid');
    range.oninput = function () {
      UI.bidValue = +range.value;
      val.textContent = fmt(UI.bidValue);
      btn.textContent = 'Bid ' + fmt(UI.bidValue);
      bar.querySelectorAll('.quick button').forEach(function (b) {
        b.classList.toggle('on',
          (b.dataset.q === 'min' && UI.bidValue === r.min) ||
          (b.dataset.q === '2x' && UI.bidValue === Math.min(r.max, 200)) ||
          (b.dataset.q === 'all' && UI.bidValue === r.max));
      });
    };
    bar.querySelectorAll('.quick button').forEach(function (b) {
      b.onclick = function () {
        let v = UI.bidValue;
        if (b.dataset.q === 'min') v = r.min;
        if (b.dataset.q === '2x') v = Math.min(r.max, 200);
        if (b.dataset.q === 'all') v = r.max;
        UI.bidValue = v; range.value = v;
        range.oninput();
      };
    });
    btn.onclick = function () {
      if (E.placeBid(S, p.id, UI.bidValue)) { UI.selected = null; render(); }
    };
  }

  /* -- select -- */
  function panelSelect(bar, s, p) {
    bar.innerHTML =
      '<button class="btn primary wide" id="btnPlay"' + (UI.selected ? '' : ' disabled') + '>' +
      (UI.selected ? 'Play Card' : 'Tap a card to lift it') + '</button>';
    $('btnPlay').onclick = function () {
      if (!UI.selected) return;
      const cid = UI.selected;
      UI.selected = null;
      if (E.playCard(S, p.id, cid)) render();
    };
  }

  /* -- round start tabs -- */
  function panelRoundStart(bar, s, p) {
    const stepTab = (s.step === 'gold') ? 'gold' : (s.step === 'cards') ? 'cards' : 'loan';
    if (UI.tabStep !== s.step) { UI.tabStep = s.step; UI.tab = stepTab; }
    const tab = UI.tab;

    const tabs = '<div class="tabs">' +
      tabBtn('gold', 'Gold', tab) + tabBtn('cards', 'Cards', tab) + tabBtn('loan', 'Loan', tab) + '</div>';

    let body = '';
    if (tab === 'gold') body = tabGold(s, p);
    else if (tab === 'cards') body = tabCards(s, p);
    else body = tabLoan(s, p);

    bar.innerHTML = tabs + '<div class="tabbody">' + body + '</div>';
    wireRoundStart(bar, s, p, tab);
  }

  function tabBtn(id, label, active) {
    return '<button data-tab="' + id + '" class="' + (active === id ? 'on' : '') + '">' + label + '</button>';
  }

  function tabGold(s, p) {
    const max = UI.goldMode === 'buy' ? Math.floor(p.cash / s.goldPrice) : p.gold;
    UI.goldQty = Math.max(0, Math.min(max, UI.goldQty || 0));
    const total = UI.goldQty * s.goldPrice;
    return '<div class="subrow">' +
      '<div class="mini-seg">' +
      '<button data-gmode="buy" class="' + (UI.goldMode === 'buy' ? 'on' : '') + '">Buy</button>' +
      '<button data-gmode="sell" class="' + (UI.goldMode === 'sell' ? 'on' : '') + '">Sell</button>' +
      '</div>' +
      '<button class="donebtn" data-gdone="1">Done</button>' +
      '</div>' +
      '<div class="goldtrade">' +
      '<div class="qty">' +
      '<button class="stepbtn" data-gold="-1">\u2212</button>' +
      '<span class="qtynum">' + UI.goldQty + '</span>' +
      '<button class="stepbtn" data-gold="1">+</button>' +
      '</div>' +
      '<button class="btn ' + (UI.goldMode === 'buy' ? 'primary' : 'gold') + '" data-goldact="1" style="flex:0 0 50%"' +
      (UI.goldQty <= 0 ? ' disabled' : '') + '>' +
      (UI.goldMode === 'buy' ? 'Buy ' : 'Sell ') + fmt(total) + '</button>' +
      '</div>';
  }

  function tabCards(s, p) {
    const cards = s.discard.slice().sort(function (a, b) { return b.r - a.r || a.s - b.s; });
    const full = p.hand.length >= E.HAND_LIMIT;
    let strip;
    if (!cards.length) {
      strip = '<div class="empty-note" style="padding:10px">Cards Space is empty</div>';
    } else {
      strip = '<div class="dstrip">' + cards.map(function (c) {
        const price = E.priceOf(c);
        const ok = p.cash >= price && !full && s.step === 'cards';
        return '<button class="dmini' + (ok ? ' buyable' : '') + ((c.s === 1 || c.s === 2) ? ' red' : '') +
          '" data-buy="' + c.id + '"' + (ok ? '' : ' disabled') + '>' +
          '<span class="r">' + E.RANK_LABEL[c.r] + '</span><span class="s">' + E.SUITS[c.s] + '</span>' +
          '<span class="pv">' + fmt(price) + '</span></button>';
      }).join('') + '</div>';
    }
    const done = s.step === 'cards'
      ? '<div class="subrow"><span class="hint" style="text-align:left">' + p.hand.length + ' / ' + E.HAND_LIMIT +
        ' cards</span><button class="donebtn" data-cdone="1">Done</button></div>'
      : '';
    return strip + done;
  }

  function tabLoan(s, p) {
    if (s.step === 'loanOffer') {
      const lp = s.loanPending;
      const b = lp ? E.byId(s, lp.borrower) : null;
      return '<div class="loanbox">' +
        '<div class="hint" style="text-align:left">' + esc(b ? b.name : '?') + ' wants to borrow <b style="color:var(--gold)">' +
        fmt(lp.amount) + '</b></div>' +
        '<div class="btnrow"><button class="btn ghost" data-offer="0">Decline</button>' +
        '<button class="btn danger" data-offer="1" style="border-color:#7a2f2a;color:#ffd9d4">Lend ' + fmt(lp.amount) + '</button></div>' +
        '</div>';
    }
    if (s.step === 'loanRequest') {
      const opts = E.loanOptions(s, p.id);
      const need = Math.max(1, E.MIN_BID - p.cash);
      if (!opts.find(function (o) { return o.id === UI.loanLender; })) UI.loanLender = opts[0].id;
      const cur = opts.find(function (o) { return o.id === UI.loanLender; }) || opts[0];
      UI.loanAmount = Math.max(need, Math.min(cur.max, UI.loanAmount || need));
      return '<div class="loanbox">' +
        '<div class="hint" style="text-align:left">Under ' + fmt(E.MIN_BID) + '. Borrow or fold.</div>' +
        '<div class="lenderrow">' + opts.map(function (o) {
          return '<button class="lender' + (o.id === UI.loanLender ? ' on' : '') + '" data-lender="' + o.id + '"' +
            (o.max < need ? ' disabled' : '') + '><b>' + esc(o.name) + '</b><span>up to ' + fmt(o.max) + '</span></button>';
        }).join('') + '</div>' +
        '<div class="goldtrade">' +
        '<div class="qty"><button class="stepbtn" data-lamt="-100">\u2212</button>' +
        '<span class="qtynum">' + fmt(UI.loanAmount) + '</span>' +
        '<button class="stepbtn" data-lamt="100">+</button></div>' +
        '<button class="btn danger" data-lgo="1" style="flex:0 0 46%;border-color:#7a2f2a;color:#ffd9d4">Borrow</button>' +
        '</div>' +
        '<button class="btn ghost" data-lfold="1" style="height:36px">Fold \u2014 leave the table</button>' +
        '</div>';
    }
    const loan = (s.loans || []).find(function (l) { return l.borrowerId === p.id; });
    return '<div class="loanbox"><div class="hint">' +
      (loan ? 'You owe ' + fmt(loan.amount) + ', due round ' + loan.dueRound + '.'
        : 'No loan needed \u2014 loans open only under ' + fmt(E.MIN_BID) + '.') +
      '</div></div>';
  }

  function wireRoundStart(bar, s, p, tab) {
    bar.querySelectorAll('[data-tab]').forEach(function (b) {
      b.onclick = function () { UI.tab = b.dataset.tab; UI.panelKey = null; renderPanel(); };
    });
    bar.querySelectorAll('[data-gmode]').forEach(function (b) {
      b.onclick = function () { UI.goldMode = b.dataset.gmode; UI.goldQty = UI.goldQty || 1; UI.panelKey = null; renderPanel(); };
    });
    bar.querySelectorAll('[data-gold]').forEach(function (b) {
      b.onclick = function () { UI.goldQty = (UI.goldQty || 0) + (+b.dataset.gold); UI.panelKey = null; renderPanel(); };
    });
    const ga = bar.querySelector('[data-goldact]');
    if (ga) ga.onclick = function () {
      if (UI.goldQty <= 0) return;
      const ok = UI.goldMode === 'buy'
        ? E.buyGold(s, p.id, UI.goldQty)
        : E.sellGold(s, p.id, UI.goldQty);
      if (ok) { UI.goldQty = 1; UI.panelKey = null; render(); }
    };
    const gd = bar.querySelector('[data-gdone]');
    if (gd) gd.onclick = function () { E.endGoldTurn(S); UI.panelKey = null; render(); };

    bar.querySelectorAll('[data-buy]').forEach(function (b) {
      b.onclick = function () {
        if (E.buyDiscardCard(s, p.id, b.dataset.buy)) { UI.panelKey = null; render(); }
      };
    });
    const cd = bar.querySelector('[data-cdone]');
    if (cd) cd.onclick = function () { E.endCardTurn(S); UI.panelKey = null; render(); };

    bar.querySelectorAll('[data-lender]').forEach(function (b) {
      b.onclick = function () { UI.loanLender = b.dataset.lender; UI.panelKey = null; renderPanel(); };
    });
    bar.querySelectorAll('[data-lamt]').forEach(function (b) {
      b.onclick = function () { UI.loanAmount = Math.max(0, (UI.loanAmount || 0) + (+b.dataset.lamt)); UI.panelKey = null; renderPanel(); };
    });
    const lg = bar.querySelector('[data-lgo]');
    if (lg) lg.onclick = function () {
      if (E.requestLoan(s, p.id, UI.loanAmount, UI.loanLender)) { UI.panelKey = null; render(); }
    };
    const lf = bar.querySelector('[data-lfold]');
    if (lf) lf.onclick = function () {
      if (confirm('Fold and leave the table?')) { E.declineLoan(s, p.id); UI.panelKey = null; render(); }
    };
    bar.querySelectorAll('[data-offer]').forEach(function (b) {
      b.onclick = function () {
        E.answerLoanOffer(s, p.id, b.dataset.offer === '1');
        UI.panelKey = null; render();
      };
    });
  }

  /* -- final sale -- */
  function panelFinal(bar, s, p) {
    bar.innerHTML =
      '<div class="bidrow"><span>Final sale \u00B7 ' + p.gold + ' gold @ ' + fmt(s.goldPrice) + '</span>' +
      '<b>' + fmt(p.gold * s.goldPrice) + '</b></div>' +
      '<div class="btnrow"><button class="btn gold" id="btnSellAll">Sell all</button>' +
      '<button class="btn ghost" id="btnKeep">Keep</button></div>';
    $('btnSellAll').onclick = function () { E.sellFinal(S, p.id, p.gold); UI.panelKey = null; render(); };
    $('btnKeep').onclick = function () { E.sellFinal(S, p.id, 0); UI.panelKey = null; render(); };
  }

  /* ---------------- bottom nav ---------------- */
  function renderNav() {
    const s = S;
    const live = s.phase === 'bid' || s.phase === 'handReveal' || s.phase === 'select' || s.phase === 'payout';
    $('bottomnav').hidden = live;
  }

  /* ---------------- gate ---------------- */
  function showGate(p, k) {
    openSheet(
      '<div class="gate">' +
      '<div class="gate-icon">\u25C8</div>' +
      '<h3>Pass the device</h3>' +
      '<p>' + esc(p.name) + ', it\u2019s your turn.</p>' +
      '<button class="btn primary wide" id="btnGate">I\u2019m ' + esc(p.name) + '</button>' +
      '</div>', 'gate-sheet', 'gate');
    $('btnGate').onclick = function () {
      UI.gateDone = k; UI.gateShowing = null; closeSheet();
      UI.panelKey = null; render();
    };
  }

  /* ---------------- hand reveal popup ---------------- */
  function showHands() {
    const s = S;
    const rows = s.players.filter(function (p) { return !p.eliminated; }).map(function (p) {
      return '<div class="hp-row"><span class="hp-name">' + esc(p.name) + '</span><span class="hp-cards">' +
        p.hand.map(function (c) {
          return '<span class="mc' + ((c.s === 1 || c.s === 2) ? ' red' : '') + '">' +
            E.RANK_LABEL[c.r] + '<i>' + E.SUITS[c.s] + '</i></span>';
        }).join('') + '</span></div>';
    }).join('');
    openSheet(
      '<div class="sh-head">Hands revealed <span class="sh-price">match ' + s.matchIndex + '</span></div>' +
      '<div class="sh-body hands-pop">' + rows + '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="hpGo">Ready</button></div>', 'hands-sheet', 'hands');
    $('hpGo').onclick = continueHands;
  }

  /* ---------------- round start price pop ---------------- */
  function showPricePop() {
    const s = S;
    const hist = s.priceHistory;
    const prev = hist.length > 1 ? hist[hist.length - 2].price : s.goldPrice;
    const d = s.goldPrice - prev;
    const dir = d > 0 ? 'up' : d < 0 ? 'down' : 'flat';
    const pct = prev ? Math.round((d / prev) * 1000) / 10 : 0;
    const vid = viewerId() || 'p0';
    const me = E.byId(s, vid);

    const data = hist.slice(-14).map(function (x) { return x.price; });
    let chart = '';
    if (data.length > 1) {
      const w = 300, h = 86;
      const mn = Math.min.apply(null, data), mx = Math.max.apply(null, data);
      const span = Math.max(40, mx - mn);
      const pts = data.map(function (v, i) {
        const px = (i / (data.length - 1)) * w;
        const py = (h - 8) - ((v - mn) / span) * (h - 20);
        return [px, py];
      });
      const line = pts.map(function (q) { return q[0].toFixed(1) + ',' + q[1].toFixed(1); }).join(' ');
      const dots = pts.map(function (q) {
        return '<circle cx="' + q[0].toFixed(1) + '" cy="' + q[1].toFixed(1) + '" r="3.4" fill="#fff" stroke="#e0a51e" stroke-width="2"/>';
      }).join('');
      chart = '<svg class="pricechart" viewBox="0 0 300 86" preserveAspectRatio="none">' +
        '<polyline points="' + line + '" fill="none" stroke="#e0a51e" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>' +
        dots + '</svg>';
    }

    openSheet(
      '<div class="pricepop">' +
      '<div class="kicker">Round ' + s.round + ' begins</div>' +
      '<div class="big ' + dir + '">' + fmt(s.goldPrice) + '</div>' +
      '<div class="move ' + dir + '">' + (dir === 'up' ? '\u25B2 +' : dir === 'down' ? '\u25BC \u2212' : '\u25AC ') +
      (d === 0 ? 'flat' : fmt(Math.abs(d)) + '  (' + pct + '%)') + '</div>' +
      chart +
      (me ? '<div class="kv" style="width:100%"><span>My gold</span><b>' + me.gold + '</b></div>' +
        '<div class="kv" style="width:100%"><span>My cash</span><b>' + fmt(me.cash) + '</b></div>' : '') +
      '<div class="sub">' + (dir === 'down' ? 'Gold is on sale \u2014 buy the dip.' :
        dir === 'up' ? 'Gold is running \u2014 sell into it.' : 'A quiet market.') + '</div>' +
      '</div>' +
      '<div class="sh-foot"><button class="btn gold wide" id="ppGo">Start Round</button></div>',
      'price-sheet', 'price');
    $('ppGo').onclick = closeSheet;
    clearTimeout(UI.priceTimer);
    UI.priceTimer = setTimeout(function () {
      if (UI.sheetKind === 'price') closeSheet();
    }, 3200);
  }

  /* ---------------- reveal ---------------- */
  function showReveal() {
    const s = S, m = s.lastMatch;
    if (!m) return;
    const rows = m.entries.map(function (e) {
      const p = E.byId(s, e.pid);
      const isWin = m.winner === e.pid;
      const isCan = m.cancelled.indexOf(e.pid) >= 0;
      const red = (e.card.s === 1 || e.card.s === 2) ? ' red' : '';
      return '<div class="rcell' + (isWin ? ' win' : '') + (isCan ? ' cancelled' : '') + '" data-pid="' + e.pid + '">' +
        '<div class="rname">' + esc(p.name) + '</div>' +
        '<div class="rcard' + red + '"><div class="rin"><div class="face front">' +
        '<span class="r">' + E.RANK_LABEL[e.card.r] + '</span><span class="s">' + E.SUITS[e.card.s] + '</span>' +
        '</div><div class="face back"></div></div></div>' +
        '<div class="rbid">' + fmt(m.bids[e.pid]) + '</div>' +
        '<div class="rtag">' + (isWin ? 'Winner' : isCan ? 'Cancelled' : '') + '</div>' +
        '</div>';
    }).join('');

    let payout;
    if (m.winner) {
      const w = E.byId(s, m.winner);
      payout = '<div class="payline"><span>' + esc(w.name) + ' collects</span><b>' + fmt(m.pot) + '</b></div>' +
        (m.bonus ? '<div class="payline"><span>Bank bonus</span><b>+' + fmt(m.bonus) + '</b></div>' : '') +
        '<div class="payline total"><span>To balance</span><b>+' + fmt(m.pot + m.bonus) + '</b></div>';
    } else {
      payout = '<div class="payline total"><span>All tied \u2014 bids returned</span><b>' + fmt(0) + '</b></div>';
    }

    openSheet(
      '<div class="sh-head">Reveal <span class="sh-price">match ' + s.matchIndex + '</span></div>' +
      '<div class="sh-body"><div class="rgrid">' + rows + '</div>' + payout + '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="rNext">Continue</button></div>',
      'reveal-sheet', 'reveal');

    setTimeout(function () {
      const cards = document.querySelectorAll('.reveal-sheet .rcard');
      cards.forEach(function (c, i) { setTimeout(function () { c.classList.add('go'); }, i * 80); });
    }, 40);

    if (m.winner) {
      setTimeout(function () {
        const win = document.querySelector('.reveal-sheet .rcell.win');
        const grid = document.querySelector('.reveal-sheet .rgrid');
        if (win && grid) flyNotes(grid, win, Math.min(9, 3 + Math.round(m.pot / 300)));
      }, 520 + m.entries.length * 80);
    }

    $('rNext').onclick = function () {
      closeSheet();
      UI.revealShown = false;
      UI.panelKey = null;
      UI.selected = null;
      E.payoutDone(S);
      render();
    };
  }

  function flyNotes(fromEl, toEl, count) {
    const a = fromEl.getBoundingClientRect();
    const b = toEl.getBoundingClientRect();
    const sx = a.left + a.width / 2, sy = a.top + a.height * 0.75;
    const tx = b.left + b.width / 2, ty = b.top + b.height * 0.35;
    for (let i = 0; i < count; i++) {
      const n = document.createElement('div');
      n.className = 'flynote';
      n.textContent = '\u20B9';
      const jx = (Math.random() - 0.5) * 90;
      const jy = (Math.random() - 0.5) * 40;
      n.style.left = (sx + jx) + 'px';
      n.style.top = (sy + jy) + 'px';
      n.style.opacity = '0';
      document.body.appendChild(n);
      const dx = tx - sx - jx, dy = ty - sy - jy;
      requestAnimationFrame(function () {
        n.style.opacity = '1';
        requestAnimationFrame(function () {
          n.style.transform = 'translate(' + dx + 'px,' + dy + 'px) scale(.7) rotate(' + (Math.random() * 40 - 20) + 'deg)';
          n.style.opacity = '0';
        });
      });
      setTimeout(function () { n.remove(); }, 1100 + i * 40);
    }
  }

  /* ---------------- round end ---------------- */
  function showRoundEnd() {
    const s = S, info = s.roundEndInfo;
    const rows = (info ? info.standings : []).map(function (r, i) {
      return '<div class="stand"><span class="pos">' + (i + 1) + '</span><span class="nm">' + esc(r.name) + '</span>' +
        '<span class="cs">' + fmt(r.cash) + '</span><span class="gd">' + r.gold + 'g</span></div>';
    }).join('');
    openSheet(
      '<div class="sh-head">Round ' + s.round + ' complete</div>' +
      '<div class="sh-body">' + (info && info.reason ? '<p class="lead">' + esc(info.reason) + '</p>' : '') +
      '<div class="kv"><span>Cards left in deck</span><b>' + s.deck.length + '</b></div>' +
      '<div class="standlist">' + rows + '</div></div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="reNext">' +
      (s.deck.length === 0 ? 'Final gold sale' : 'Next round') + '</button></div>', 'round-sheet', 'round');
    $('reNext').onclick = function () {
      closeSheet(); UI.panelKey = null; UI.handsShown = false; UI.revealShown = false;
      E.nextRound(S); render();
    };
  }

  /* ---------------- results ---------------- */
  function showResults() {
    const s = S, res = s.results;
    const top = res.rows.slice(0, 3);
    const order = [1, 0, 2];
    const podium = order.filter(function (i) { return top[i]; }).map(function (i) {
      const r = top[i];
      return '<div class="pod p' + r.rank + '"><div class="medal">' + (r.rank === 1 ? '\u265B' : '') + '</div>' +
        '<div class="who">' + esc(r.name) + '</div>' +
        '<div class="amt">' + fmt(r.cash) + '</div>' +
        '<div class="block">' + r.rank + '</div></div>';
    }).join('');
    const rows = res.rows.map(function (r) {
      return '<div class="stand' + (r.rank === 1 ? ' first' : '') + (r.eliminated ? ' elim' : '') + '">' +
        '<span class="pos">' + r.rank + '</span><span class="nm">' + esc(r.name) + '</span>' +
        '<span class="cs">' + fmt(r.cash) + '</span>' +
        '<span class="gd">' + (r.goldSold ? r.goldSold + 'g sold' : '') + '</span></div>';
    }).join('');
    openSheet(
      '<div class="sh-head">Results</div>' +
      '<div class="sh-body">' +
      '<div class="podium">' + podium + '</div>' +
      '<div class="kv"><span>Rounds played</span><b>' + res.rounds + '</b></div>' +
      '<div class="kv"><span>Closing gold</span><b>' + fmt(res.goldPrice) + '</b></div>' +
      '<div class="standlist">' + rows + '</div></div>' +
      '<div class="sh-foot"><button class="btn ghost" id="resMenu">Menu</button>' +
      '<button class="btn primary" id="resAgain">Play again</button></div>', 'result-sheet', 'results');
    $('resMenu').onclick = function () { closeSheet(); S = null; goHome(); };
    $('resAgain').onclick = function () { closeSheet(); startGame(); };
  }

  /* ---------------- side sheets ---------------- */
  function showLeaderboard() {
    const s = S;
    const rows = s.players.map(function (p) {
      return { n: p.name, v: p.cash + p.gold * s.goldPrice, c: p.cash, g: p.gold, e: p.eliminated };
    }).sort(function (a, b) { return b.v - a.v; });
    openSheet(
      '<div class="sh-head">Leaderboard <span class="sh-price">net worth</span></div>' +
      '<div class="sh-body"><div class="standlist">' + rows.map(function (r, i) {
        return '<div class="stand' + (i === 0 ? ' first' : '') + (r.e ? ' elim' : '') + '">' +
          '<span class="pos">' + (i + 1) + '</span><span class="nm">' + esc(r.n) + '</span>' +
          '<span class="cs">' + fmt(r.v) + '</span><span class="gd">' + r.g + 'g</span></div>';
      }).join('') + '</div></div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="lbClose">Close</button></div>', 'log-sheet', 'leaderboard');
    $('lbClose').onclick = closeSheet;
  }

  function showProfile() {
    const s = S;
    const vid = viewerId() || 'p0';
    const p = E.byId(s, vid);
    if (!p) return;
    const w = E.byId(s, p.id);
    openSheet(
      '<div class="sh-head">Profile</div>' +
      '<div class="sh-body">' +
      '<div class="kv"><span>Name</span><b>' + esc(p.name) + '</b></div>' +
      '<div class="kv"><span>Cash</span><b>' + fmt(p.cash) + '</b></div>' +
      '<div class="kv"><span>Gold</span><b>' + p.gold + ' @ ' + fmt(s.goldPrice) + '</b></div>' +
      '<div class="kv"><span>Net worth</span><b>' + fmt(p.cash + p.gold * s.goldPrice) + '</b></div>' +
      '<div class="kv"><span>Matches won</span><b>' + p.wins + '</b></div>' +
      '<div class="kv"><span>Gold bought / sold</span><b>' + p.goldBought + ' / ' + p.goldSold + '</b></div>' +
      '<div class="kv"><span>Spent on cards</span><b>' + fmt(p.spent) + '</b></div>' +
      '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="prClose">Close</button></div>', 'log-sheet', 'profile');
    $('prClose').onclick = closeSheet;
  }

  function showShop() {
    openSheet(
      '<div class="sh-head">Shop <span class="sh-price">RIX</span></div>' +
      '<div class="sh-body">' +
      '<p class="lead">You have <b>' + PROFILE.rix + ' RIX</b>. Nothing to spend it on yet \u2014 the table economy is cash and gold only, so RIX has no source and no sink.</p>' +
      '<div class="warn">Table themes, card backs and avatar frames would slot in here once RIX can be earned.</div>' +
      '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="shClose">Close</button></div>', 'log-sheet', 'shop');
    $('shClose').onclick = closeSheet;
  }

  function showRules() {
    openSheet(
      '<div class="sh-head">How to play</div>' +
      '<div class="sh-body rules">' +
      '<h4>The table</h4><p>2\u20136 players. Everyone starts with cash and 5 cards from a shuffled 52-card deck. 2 is low, Ace is high. Suits mean nothing.</p>' +
      '<h4>Gold</h4><p>Opens at \u20B91,000 a biscuit, moves between \u20B91,000 and \u20B95,000 at the start of every round. Trade only at round start.</p>' +
      '<h4>A round</h4><p>New gold price \u2192 buy/sell gold \u2192 buy cards from the Cards Space \u2192 loans come due. Then the matches are played.</p>' +
      '<h4>A match</h4><p>Everyone locks a bid of at least \u20B9100, hidden until all are in. Hands are revealed, then hidden. Everyone plays one card face down. Highest rank wins. Ties at the top are cancelled and the next rank wins. If everyone ties, bids come back.</p>' +
      '<h4>Payout</h4><p>The winner takes every opponent\u2019s bid, plus half their own bid from the bank if they bid above \u20B9100. Played cards go to the Cards Space.</p>' +
      '<h4>Buying cards</h4><p>J \u20B9300, Q \u20B9500, K \u20B9700, A \u20B91,000; number cards \u20B950\u2013\u20B9250. Hand limit 7.</p>' +
      '<h4>Loans</h4><p>Under \u20B9100 you can\u2019t bid. Borrow from the bank (up to \u20B92,000) or a player who agrees. Repay at the next round start or you\u2019re out.</p>' +
      '<h4>Game end</h4><p>When the draw deck empties, everyone sells gold at the closing price. Highest cash wins.</p>' +
      '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="ruClose">Got it</button></div>', 'rules-sheet', 'rules');
    $('ruClose').onclick = closeSheet;
  }

  function showLog() {
    const items = S.log.slice(0, 120).map(function (l) {
      return '<div class="logline k-' + l.kind + '"><span class="lr">R' + l.round + '</span>' + esc(l.text) + '</div>';
    }).join('');
    openSheet('<div class="sh-head">Action log</div><div class="sh-body loglist">' +
      (items || '<div class="empty-note">Nothing yet.</div>') + '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="lgClose">Close</button></div>', 'log-sheet', 'log');
    $('lgClose').onclick = closeSheet;
  }

  function showDiscard() {
    const s = S;
    const vid = viewerId();
    const p = vid ? E.byId(s, vid) : null;
    const canBuy = !!(p && !p.isBot && s.step === 'cards' && s.actor === p.id);
    const cards = s.discard.slice().sort(function (a, b) { return b.r - a.r || a.s - b.s; });
    openSheet(
      '<div class="sh-head">Cards Space <span class="sh-price">' + cards.length + ' cards</span></div>' +
      '<div class="sh-body">' +
      (cards.length ? '<div class="dstrip" style="flex-wrap:wrap;overflow:visible;min-height:0">' + cards.map(function (c) {
        const price = E.priceOf(c);
        const ok = canBuy && p.cash >= price && p.hand.length < E.HAND_LIMIT;
        return '<button class="dmini' + (ok ? ' buyable' : '') + ((c.s === 1 || c.s === 2) ? ' red' : '') +
          '" data-b="' + c.id + '"' + (ok ? '' : ' disabled') + ' style="width:52px;height:68px">' +
          '<span class="r">' + E.RANK_LABEL[c.r] + '</span><span class="s">' + E.SUITS[c.s] + '</span>' +
          '<span class="pv">' + fmt(price) + '</span></button>';
      }).join('') + '</div>' : '<div class="empty-note">Played cards land here.</div>') +
      '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="dsClose">Close</button></div>', 'discard-sheet', 'discard');
    $('dsClose').onclick = closeSheet;
    document.querySelectorAll('.discard-sheet [data-b]').forEach(function (b) {
      b.onclick = function () {
        if (!canBuy) return;
        if (E.buyDiscardCard(s, p.id, b.dataset.b)) { closeSheet(); UI.panelKey = null; render(); }
      };
    });
  }

  function showGameMenu() {
    openSheet(
      '<div class="sh-head">Menu</div>' +
      '<div class="sh-body menu">' +
      '<button class="btn wide" id="mRules">Rules</button>' +
      '<button class="btn wide" id="mLog">Action log</button>' +
      '<button class="btn wide" id="mSave">Save &amp; exit to menu</button>' +
      '<button class="btn wide danger" id="mNew">Abandon &amp; start over</button>' +
      '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="mClose">Back to the table</button></div>', 'menu-sheet', 'menu');
    $('mRules').onclick = showRules;
    $('mLog').onclick = showLog;
    $('mSave').onclick = function () { UI.saved = S; closeSheet(); S = null; goHome(); };
    $('mNew').onclick = function () {
      if (confirm('Abandon this game and return home?')) { S = null; closeSheet(); goHome(); }
    };
    $('mClose').onclick = closeSheet;
  }

  /* ---------------- menu wiring ---------------- */
  function refreshMenu() {
    $('btnContinue').hidden = !UI.saved;
    $('btnContinue').textContent = UI.saved ? 'Resume saved game' : '';
    $('botRow').style.display = UI.mode === 'bots' ? '' : 'none';
    $('cfgPlayersVal').textContent = UI.players;
    $('cfgPlayers').value = UI.players;
    $('cfgCashVal').textContent = UI.cash.toLocaleString('en-IN');
    $('cfgCash').value = UI.cash;
  }

  function bindMenu() {
    document.querySelectorAll('#modeSeg button').forEach(function (b) {
      b.onclick = function () {
        UI.mode = b.dataset.mode;
        document.querySelectorAll('#modeSeg button').forEach(function (x) { x.classList.toggle('on', x === b); });
        refreshMenu();
      };
    });
    document.querySelectorAll('#diffSeg button').forEach(function (b) {
      b.onclick = function () {
        UI.diff = b.dataset.diff;
        document.querySelectorAll('#diffSeg button').forEach(function (x) { x.classList.toggle('on', x === b); });
      };
    });
    $('cfgPlayers').oninput = function () { UI.players = +this.value; refreshMenu(); };
    $('cfgCash').oninput = function () { UI.cash = +this.value; refreshMenu(); };
    $('btnStart').onclick = startGame;
    $('btnContinue').onclick = function () {
      if (!UI.saved) return;
      S = UI.saved; UI.saved = null;
      resetTurnUI();
      showScreen('game'); render();
    };
    $('btnRules').onclick = showRules;
  }

  function bindBoard() {
    $('btnMenu').onclick = showGameMenu;
    $('deckPile').onclick = function () {
      openSheet('<div class="sh-head">Draw deck</div><div class="sh-body"><p class="lead">' + S.deck.length +
        ' cards left. When it hits zero the game is over.</p></div>' +
        '<div class="sh-foot"><button class="btn primary wide" id="dkC">Close</button></div>', 'log-sheet', 'deck');
      $('dkC').onclick = closeSheet;
    };
    $('discardPile').onclick = showDiscard;

    $('hand').addEventListener('click', function (ev) {
      const btn = ev.target.closest('[data-card]');
      if (!btn) return;
      const s = S;
      const vid = viewerId();
      const p = vid ? E.byId(s, vid) : null;
      if (!p || p.isBot || s.phase !== 'select' || s.actor !== p.id) return;
      const id = btn.dataset.card;
      if (UI.selected === id) {                       // tap again = confirm
        UI.selected = null;
        if (E.playCard(S, p.id, id)) { UI.panelKey = null; render(); }
        return;
      }
      UI.selected = id;                                // tap once = lift
      renderHand();
      UI.panelKey = null;
      renderPanel();
    });

    document.querySelectorAll('#bottomnav button').forEach(function (b) {
      b.onclick = function () {
        if (!S) return;
        const n = b.dataset.nav;
        if (n === 'leaderboard') showLeaderboard();
        else if (n === 'profile') showProfile();
        else showShop();
      };
    });

    $('overlay').addEventListener('click', function (ev) {
      if (ev.target !== $('overlay')) return;
      const keep = ['gate', 'reveal', 'hands', 'round', 'results', 'price'];
      if (keep.indexOf(UI.sheetKind) >= 0) return;
      closeSheet();
    });
  }

  function boot() {
    bindMenu();
    bindBoard();
    bindHome();
    bindTableSelect();
    refreshMenu();
    showScreen('splash');
    spawnFloaties();
    runLoader();
  }

  function runLoader() {
    const fill = $('loadFill'), pct = $('loadPct'), acts = $('splashActions');
    if (!fill) return;
    const t0 = performance.now(), dur = 2000;
    function step(now) {
      const p = Math.min(1, (now - t0) / dur);
      fill.style.width = (p * 100) + '%';
      pct.textContent = Math.round(p * 100) + '%';
      if (p < 1) requestAnimationFrame(step);
      else if (acts) acts.classList.add('show');
    }
    requestAnimationFrame(step);
  }

  function spawnFloaties() {
    const wrap = $('floaties');
    if (!wrap) return;
    wrap.innerHTML = '';
    const kinds = ['assets/ic-cash1.webp', 'assets/ic-gold1.webp'];
    for (let i = 0; i < 8; i++) {
      const img = document.createElement('img');
      img.className = 'flimg';
      img.src = kinds[i % 2];
      img.alt = '';
      const isNote = (i % 2 === 0);
      const size = (isNote ? 40 : 30) + Math.random() * 22;
      const dur = 6 + Math.random() * 6;
      const r0 = isNote ? (Math.random() * 16 - 8) : (Math.random() * 80 - 40);
      const r1 = isNote ? (r0 + (Math.random() * 36 - 18)) : (r0 + Math.random() * 260 + 120);
      img.style.width = size + 'px';
      img.style.left = (Math.random() * 86) + '%';
      img.style.animationDuration = dur + 's';
      img.style.animationDelay = (-Math.random() * dur) + 's';
      img.style.setProperty('--r0', r0.toFixed(1) + 'deg');
      img.style.setProperty('--r1', r1.toFixed(1) + 'deg');
      img.style.setProperty('--dx', (Math.random() * 90 - 45) + 'px');
      img.style.opacity = (0.85 + Math.random() * 0.15).toFixed(2);
      wrap.appendChild(img);
    }
  }

  function bindHome() {
    ['btnGuest', 'btnGoogle', 'btnPhone'].forEach(function (id) {
      const el = $(id);
      if (el) el.onclick = function () { goHome(); };
    });
    $('btnSetupBack').onclick = function () { goHome(); };

    function toTableSelect(bots) {
      UI.mode = bots ? 'bots' : 'local';
      syncModeSeg();
      renderTableSelect();
      showScreen('tableSelect');
    }
    $('btnPlay').onclick = function () { toTableSelect(false); };
    $('btnBots').onclick = function () { toTableSelect(true); };
    $('btnPass').onclick = function () { toast('Coming soon'); };
    $('btnPrivate').onclick = function () { toast('Coming soon'); };
    $('btnBuyRix').onclick = function () { toast('Buy RIX coming soon'); };
    $('btnGift').onclick = function () { toast('Coming soon'); };
    $('btnMissions').onclick = function () { toast('Coming soon'); };
    $('btnProfileBadge').onclick = function () { toast('Coming soon'); };
    $('navHome').onclick = function () { };
    $('navShop').onclick = function () { toast('Coming soon'); };
    $('navProfile').onclick = function () { toast('Coming soon'); };
    $('navLeaderboard').onclick = function () { toast('Coming soon'); };
    $('navRules').onclick = function () { toast('Coming soon'); };


    const homeEl = $('homeScreen');
    homeEl.addEventListener('pointerdown', function (ev) {
      if (ev.target.closest('button')) playTap();
    }, true);

    window.addEventListener('resize', function () { fitHome(); scaleBuyIn(); });
    if (window.visualViewport) window.visualViewport.addEventListener('resize', scaleBuyIn);
    window.addEventListener('orientationchange', fitHome);

    let secs = 23 * 3600 + 45 * 60 + 17;
    setInterval(function () {
      secs = Math.max(0, secs - 1);
      const h = String(Math.floor(secs / 3600)).padStart(2, '0');
      const m = String(Math.floor((secs % 3600) / 60)).padStart(2, '0');
      const ss = String(secs % 60).padStart(2, '0');
      const el = $('giftTimer');
      if (el) el.textContent = h + ':' + m + ':' + ss;
    }, 1000);
  }

  /* ---------------- table select ---------------- */
  const TIERS = {
    rookie: { cap: 2000, top: 235, h: 265, name: 'Rookie' },
    pro:    { cap: 5000, top: 530, h: 270, name: 'Pro' },
    high:   { cap: 10000, top: 838, h: 332, name: 'High Roller' }
  };
  const TS = { tier: 'rookie', players: 4, mode: 'friendly', amount: 2000, counts: [128, 64, 12] };

  function renderTableSelect() {
    const wallet = PROFILE.cash;
    const proLocked = wallet < 5000;
    const highLocked = wallet < 10000;

    $('cnt0').style.display = '';
    $('cnt1').style.display = proLocked ? 'none' : '';
    $('cnt2').style.display = '';

    $('lockPro').classList.toggle('on', proLocked);
    $('lockHigh').classList.toggle('on', highLocked);
    $('needPro').classList.toggle('on', proLocked);
    $('needHigh').classList.toggle('on', highLocked);

    $('dimPro').style.cssText = 'left:30px;top:530px;width:881px;height:270px';
    $('dimHigh').style.cssText = 'left:30px;top:838px;width:881px;height:320px';
    $('dimPro').classList.toggle('on', proLocked);
    $('dimHigh').classList.toggle('on', highLocked);

    const t = TIERS[TS.tier];
    const ol = $('tsOutline');
    ol.style.left = '30px'; ol.style.width = '881px';
    ol.style.top = (t.top - 10) + 'px';
    ol.style.height = (t.h + 20) + 'px';

    $('rimFriendly').classList.toggle('on', TS.mode === 'friendly');
    $('rimRanked').classList.toggle('on', TS.mode === 'ranked');

    const hl = $('pnHl');
    const sel = document.querySelector('.pn[data-n="' + TS.players + '"]');
    if (hl && sel) { hl.style.left = sel.style.left; hl.style.width = sel.style.width; }
    document.querySelectorAll('.pn').forEach(function (b) {
      b.classList.toggle('on', +b.dataset.n === TS.players);
    });
    fitHome();
  }

  function setCounts() {
    for (let i = 0; i < 3; i++) {
      const el = $('cnt' + i);
      if (el) el.querySelector('span').textContent = TS.counts[i] + ' playing';
    }
  }

  function selectTier(k) {
    if (PROFILE.cash < TIERS[k].cap) {
      toast('Need ' + Math.round(TIERS[k].cap).toLocaleString('en-IN') + ' cash');
      return;
    }
    TS.tier = k;
    renderTableSelect();
  }

  function buyInRange() {
    const cap = TIERS[TS.tier].cap;
    let max = Math.min(cap, PROFILE.cash);
    const min = 1000;
    if (PROFILE.cash < 1000 && TS.tier === 'rookie') max = 2000;   // newbie gift
    if (max < min) max = min;
    return { min: min, max: max };
  }

  const BI_ART = { x0: 19, x1: 1102, y0: 0, y1: 1324, w: 1083, h: 1324 };

  function scaleBuyIn() {
    const sheet = $('biSheet'), inner = $('biInner');
    if (!sheet || !inner) return;
    const vv = window.visualViewport;
    const vw = vv ? vv.width : window.innerWidth;
    const vh = vv ? vv.height : window.innerHeight;

    let sc = (0.92 * vw) / BI_ART.w;
    const cap = (0.88 * vh) / BI_ART.h;
    if (sc > cap) sc = cap;

    const left = (vw - BI_ART.w * sc) / 2 - BI_ART.x0 * sc;
    const top = (vh - BI_ART.h * sc) / 2 - BI_ART.y0 * sc;

    sheet.style.left = left + 'px';
    sheet.style.top = top + 'px';
    sheet.style.width = (1122 * sc) + 'px';
    sheet.style.height = (1402 * sc) + 'px';
    inner.style.transform = 'scale(' + sc + ')';
  }

  function openBuyIn() {
    const r = buyInRange();
    if (!TS.amountTouched) TS.amount = r.max;
    TS.amount = Math.max(r.min, Math.min(r.max, TS.amount));
    $('biOverlay').hidden = false;
    requestAnimationFrame(function () {
      $('biOverlay').classList.add('in');
      scaleBuyIn();
      renderBuyIn();
    });
  }

  function closeBuyIn() {
    $('biOverlay').classList.remove('in');
    setTimeout(function () { $('biOverlay').hidden = true; }, 190);
  }

  function renderBuyIn() {
    const r = buyInRange();
    TS.amount = Math.max(r.min, Math.min(r.max, Math.round(TS.amount / 100) * 100));

    $('biAmount').textContent = Math.round(TS.amount).toLocaleString('en-IN');

    const pct = (TS.amount - r.min) / Math.max(1, r.max - r.min);
    const knobX = 243 + pct * 634;          // knob centre stays clear of both buttons
    $('biKnob').style.left = knobX + 'px';
    $('biFill').style.width = (knobX - 215) + 'px';

    const after = PROFILE.cash - TS.amount;
    $('biWallet').innerHTML = Math.round(PROFILE.cash).toLocaleString('en-IN') +
      ' &rarr; <em>' + Math.round(after).toLocaleString('en-IN') + '</em>';

    const chips = [['biChip1', 1000], ['biChip2', 2000], ['biChipMax', r.max]];
    let hit = null;
    chips.forEach(function (c) {
      const el = $(c[0]);
      el.classList.toggle('dim', c[1] > r.max);
      if (c[1] <= r.max && TS.amount === c[1] && !hit) hit = c[0];
    });
    const RING = {
      biChip1: ['97px', '808px', '290px'],
      biChip2: ['411px', '808px', '301px'],
      biChipMax: ['736px', '808px', '290px']
    };
    const ring = $('biRing');
    if (hit) {
      const g = RING[hit];
      ring.style.left = g[0]; ring.style.top = g[1]; ring.style.width = g[2]; ring.style.height = '110px';
      ring.classList.add('on');
    } else { ring.classList.remove('on'); }
  }

  function nudgeAmount(delta) {
    const r = buyInRange();
    TS.amountTouched = true;
    TS.amount = Math.max(r.min, Math.min(r.max, TS.amount + delta));
    renderBuyIn();
  }

  function joinTable() {
    PROFILE.cash = Math.max(0, PROFILE.cash - TS.amount);
    renderHome();
    closeBuyIn();
    $('lobbyInfo').textContent = TIERS[TS.tier].name + ' table \u00B7 ' + TS.players +
      ' players \u00B7 buy-in ' + Math.round(TS.amount).toLocaleString('en-IN');
    showScreen('lobby');
  }


  /* ================= GAME TABLE ================= */
  const TB = { s: null, sel: null, bid: 0, timer: null, av: {} };

  const SEAT_ME = [0.50,0.735];
  const BOT_NAMES = ['Rohan','Diya','Arjun','Varun','Ananya'];
  const BOT_AV = ['av-rohan','av-diya','av-arjun','av-varun','av-ananya'];

  // chair centres measured from table.png by clustering red pixels
  const PLAY_SLOTS = {
    3: { x: 47, y: 38 },   // Arjun  top-centre
    1: { x: 37, y: 50 },   // Rohan  left
    5: { x: 56, y: 50 },   // Ananya right
    0: { x: 47, y: 61 }    // You    bottom-centre
  };

  // chair centres as % of table.png (red-pixel clusters), measured
  const CHAIRS = [
    { cx: 49.9, cy: 89.4 },   // 0 bottom
    { cx: 9.9,  cy: 46.8 },   // 1 mid-left
    { cx: 13.5, cy: 16.1 },   // 2 top-left (unused)
    { cx: 49.9, cy: 5.2 },    // 3 top
    { cx: 86.4, cy: 16.0 },   // 4 top-right (unused)
    { cx: 89.9, cy: 46.8 }    // 5 mid-right
  ];
  // seat -> chair, avatar width as a fraction of stage width, dy in table heights
  const SEATS = [
    { chair: 0, w: 0.21, dy: -0.02 },              // You
    { chair: 1, w: 0.19, dy: 0.03, sx: 0.165 },   // Rohan  (x = % of stage W)
    { chair: 2, w: 0.30, dy: 0 },                  // unused
    { chair: 3, w: 0.19, dy: 0.098 },              // Arjun  (50px higher)
    { chair: 4, w: 0.30, dy: 0 },                  // unused
    { chair: 5, w: 0.19, dy: 0.03, sx: 0.835 }    // Ananya (x = % of stage W)
  ];
  let LAY = { W: 390, tableLeft: 0, tableTop: 0, tableW: 390, tableH: 372, anchors: [] };
  const USED_BY_N = {
    2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 5], 5: [0, 1, 2, 4, 5], 6: [0, 1, 2, 3, 4, 5]
  };
  const CHAR_FILES = ['char0', 'char1', 'char2', 'char3', 'char4', 'char5'];

  function usedSeats(n) { return USED_BY_N[Math.max(2, Math.min(6, n))] || USED_BY_N[6]; }

  let PLATE_AR = 2.5;
  (function () {
    const im = new Image();
    im.onload = function () {
      PLATE_AR = 685 / 245;
      document.documentElement.style.setProperty('--plate-ar', PLATE_AR.toFixed(4));
      if (TB && TB.s) renderTable();
    };
    im.src = 'assets/game/plate.webp';
  })();

  function fitTable() {
    const st = $('stage'), g = $('tableGroup'), img = $('tableImg');
    if (!st || !g || !img) return;
    const vv = window.visualViewport;
    const vw = Math.round(vv ? vv.width : window.innerWidth);
    const vh = Math.round(vv ? vv.height : window.innerHeight);
    const panel = document.querySelector('.tb-panel');
    const bidH = panel ? panel.getBoundingClientRect().height : 150;
    const strip = $('handStrip');
    const stripH = strip ? strip.getBoundingClientRect().height : 104;
    const hudH = 56;
    const availH = Math.max(80, vh - hudH - bidH - stripH);
    st.style.top = hudH + 'px';
    st.style.bottom = bidH + 'px';
    st.style.height = 'auto';
    const W = vw;
    const natW = img.naturalWidth || 917, natH = img.naturalHeight || 876;
    const ratio = natW / natH;
    const tableScale = parseFloat(getComputedStyle(st).getPropertyValue('--tableScale')) || 0.94;
    const tableW = Math.min(W * tableScale, availH * ratio);
    const tableH = tableW / ratio;
    const tableLeft = (W - tableW) / 2;
    const VBias = 20;                              // share the slack: table sits lower
    const tableTop = (availH - tableH) / 2 + VBias;
    st.style.setProperty('--W', W + 'px');
    g.style.width = Math.round(tableW) + 'px';
    g.style.height = Math.round(tableH) + 'px';
    g.style.left = (tableLeft + tableW / 2) + 'px';
    g.style.top = (tableTop + tableH / 2) + 'px';
    const anchors = CHAIRS.map(function (c) {
      return { x: tableLeft + (c.cx / 100) * tableW, y: tableTop + (c.cy / 100) * tableH };
    });
    LAY = { W: W, tableLeft: tableLeft, tableTop: tableTop, tableW: tableW, tableH: tableH, anchors: anchors, availH: availH };
    window.__LAY = LAY;
    if ($('dbgFit') && /[?&]debug=1/.test(location.search)) {
      $('dbgFit').style.display = 'block';
      const ver = document.body.getAttribute('data-build') || '?';
      $('dbgFit').textContent = ver + ' | W ' + W + ' availH ' + Math.round(availH) +
        ' table ' + Math.round(tableW) + 'x' + Math.round(tableH) +
        ' at ' + Math.round(tableLeft) + ',' + Math.round(tableTop) + ' scale ' + tableScale;
    } else if ($('dbgFit')) $('dbgFit').style.display = 'none';
  }

  function demoPlayed() {
    const s = TB.s; if (!s) return;
    const ids = (s.matchPlayers && s.matchPlayers.length) ? s.matchPlayers : s.players.map(function (p) { return p.id; });
    ids.forEach(function (id) {
      const p = Engine.byId(s, id);
      if (p && p.hand && p.hand[0] && !s.plays[id]) s.plays[id] = p.hand[0];
    });
    renderTable();
  }

  function startTable() {
    const n = Math.max(2, Math.min(6, TS.players || 6));
    const seats = usedSeats(n);
    const names = ['You', 'Rohan', 'Diya', 'Arjun', 'Varun', 'Ananya'];
    const players = seats.map(function (seat, i) {
      return { name: i === 0 ? 'You' : names[seat], isBot: i > 0, bot: 'normal', seat: seat, avatarId: seat };
    });
    const s = Engine.newGame({ players: players, startingCash: TS.amount, seed: (Date.now() % 99991) + 1, rounds: CFG.rounds });
    s.players.forEach(function (p, i) { p.seat = seats[i]; p.avatarId = seats[i]; });
    TB.bid = 100;
    TB.s = s; TB.sel = null; TB.faceUp = false; TB.revStarted = false; TB.prevGold = null; TB.goldRound = 0; TB_GOLD_SHOWN = null; TB.bidRound = null;
    Engine.startRound(s);
    showScreen('table');
    fitTable();
    renderTable();
    updateBidUI();
    if (/[?&]demo=played/.test(location.search)) {
      let n = 0;
      const t = setInterval(function () {
        demoPlayed();
        if (++n > 24) clearInterval(t);
      }, 400);
    }
    openRoundStart();
  }

  function autoRoundStart() {
    const s = TB.s; let guard = 0;
    while (s.phase === 'roundStart' && guard++ < 120) {
      const p = s.actor ? Engine.byId(s, s.actor) : null;
      if (!p) break;
      if (s.step === 'gold') Engine.endGoldTurn(s);
      else if (s.step === 'cards') Engine.endCardTurn(s);
      else if (s.step === 'loanRequest') {
        const d = Bots.loanRequest(s, p);
        if (d && d.decline) Engine.declineLoan(s, p.id);
        else if (d) Engine.requestLoan(s, p.id, d.amount, d.lender);
        else Engine.declineLoan(s, p.id);
      } else if (s.step === 'loanOffer') Engine.answerLoanOffer(s, s.actor, true);
      else break;
    }
  }

  function cardFace(rank, suit) {
    const R = { 11: 'J', 12: 'Q', 13: 'K', 14: 'A' };
    return 'card-' + (R[rank] || rank) + 'SDHC'[suit];
  }
  const CARD_OK = {}; ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
    .forEach(r => 'SDHC'.split('').forEach(su => CARD_OK['card-' + r + su] = 1));

  function cardImg(card, cls) {
    const name = cardFace(card.r, card.s);
    const el = document.createElement('div');
    el.className = cls;
    if (CARD_OK[name]) {
      const img = document.createElement('img');
      img.src = 'assets/game/' + name + '.webp';
      el.appendChild(img);
    } else el.textContent = 'MISSING ' + name;
    return el;
  }

  let TB_GOLD_SHOWN = null, TB_GOLD_ANIM = null;

  function renderTable() {
    const s = TB.s; if (!s) return;
    $('tbRound').textContent = 'Round ' + s.round + ' - Match ' +
      Math.min(s.matchIndex, s.matchesThisRound) + '/' + s.matchesThisRound;
    renderGoldPrice(s);

    const seatsEl = $('tbSeats'); seatsEl.innerHTML = '';
    s.players.forEach(function (p) {
      const pos = SEATS[p.seat != null ? p.seat : 0];
      const anc = LAY.anchors[pos.chair] || { x: LAY.W / 2, y: LAY.tableTop };
      const box = document.createElement('div');
      box.className = 'tb-seatbox' + (p.id === 'p0' ? ' me' : '');
      box.style.width = 'calc(var(--W,390px) * ' + (pos.w || 0.19) + ')';
      box.style.left = Math.round(pos.sx ? pos.sx * LAY.W : anc.x) + 'px';
      box.style.top = Math.round(anc.y + (pos.dy || 0) * LAY.tableH) + 'px';
      const av = p.avatarId != null ? p.avatarId : (p.seat || 0);
      const img = document.createElement('img');
      img.className = 'tb-char';
      img.src = 'assets/game/' + CHAR_FILES[av] + '.webp';
      img.alt = p.name;
      img.style.width = 'calc(var(--W,390px) * ' + (pos.w || 0.30) + ')';
      box.appendChild(img);

      const plate = document.createElement('div');
      plate.className = 'tb-plate';
      plate.innerHTML = '<img class="plate-bg" src="assets/game/plate.webp" alt="">' +
        '<div class="plate-text"><span class="pname">' + p.name + '</span>' +
        '<span class="pcash"><img class="note" src="assets/game/ic-cash1.webp" alt="">' +
        Math.round(p.cash).toLocaleString('en-IN') +
        '<img class="bar" src="assets/game/ic-gold.webp" alt="">' + p.gold + '</span></div>';
      if (s.bids && s.bids[p.id] != null) {
        const lk = document.createElement('span');
        lk.className = 'tb-lock on';
        lk.innerHTML = '<img src="assets/game/ui-lock.webp" alt="">Bid Locked';
        plate.appendChild(lk);
      }


      box.appendChild(plate);
      seatsEl.appendChild(box);
      if (p.id === 'p0') { plate.style.zIndex = 12; }
    });

    // shrink plate text only where it would overflow (long cash values)
    document.querySelectorAll('.plate-text').forEach(function (tx) {
      const nm = tx.querySelector('.pname'), r2 = tx.querySelector('.pcash');
      [nm, r2].forEach(function (el) {
        if (!el) return;
        el.style.fontSize = '';
        let size = parseFloat(getComputedStyle(el).fontSize);
        let guard = 0;
        while (tx.scrollWidth > tx.clientWidth + 1 && size > 9 && guard++ < 24) {
          size -= 0.5;
          el.style.fontSize = size + 'px';
        }
      });
    });

    // played cards live above avatars and plates
    const play = $('playLayer');
    if (play) {
      play.innerHTML = '';
      const lm = s.lastMatch;
      s.players.forEach(function (p) {
        let card = s.plays && s.plays[p.id];
        if (!card && lm && lm.entries) {
          const e = lm.entries.filter(function (x) { return x.pid === p.id; })[0];
          if (e && e.card) card = e.card;
        }
        if (!card) return;
        const slot = PLAY_SLOTS[p.seat != null ? p.seat : 0] || { x: 50, y: 52 };
        const faceUp = !!TB.faceUp;
        const el = document.createElement('div');
        el.className = 'tb-played' + (faceUp ? ' flipped' : '');
        el.dataset.pid = p.id;
        const inner = document.createElement('div');
        inner.className = 'card-inner';
        const back = document.createElement('div');
        back.className = 'card-back';
        const bimg = document.createElement('img');
        bimg.src = 'assets/game/back.webp';
        back.appendChild(bimg);
        const front = document.createElement('div');
        front.className = 'card-front';
        const fimg = document.createElement('img');
        fimg.src = 'assets/game/' + cardFace(card.r, card.s) + '.webp';
        front.appendChild(fimg);
        inner.appendChild(back); inner.appendChild(front);
        el.appendChild(inner);
        el.style.left = Math.round(LAY.tableLeft + LAY.tableW * (slot.x / 100)) + 'px';
        el.style.top = Math.round(LAY.tableTop + LAY.tableH * (slot.y / 100)) + 'px';
        play.appendChild(el);
      });
    }

    // piles on the felt
    const piles = $('tbPiles'); piles.innerHTML = '';
    for (let i = 0; i < 3; i++) {
      const b = document.createElement('div');
      b.className = 'tb-pilecard';
      b.innerHTML = '<img src="assets/game/back.webp" alt="">';
      b.style.left = Math.round(LAY.tableLeft + LAY.tableW * 0.40 - i * 2) + 'px';
      b.style.top = Math.round(LAY.tableTop + LAY.tableH * 0.30 - i * 2) + 'px';
      piles.appendChild(b);
    }
    const top = s.discard[s.discard.length - 1];
    if (!top) {
      const e = document.createElement('div');
      e.className = 'tb-empty';
      e.style.left = Math.round(LAY.tableLeft + LAY.tableW * 0.60) + 'px';
      e.style.top = Math.round(LAY.tableTop + LAY.tableH * 0.30) + 'px';
      piles.appendChild(e);
    } else {
      for (let i = 1; i >= 0; i--) {
        const c = cardImg(top, 'tb-pilecard');
        c.style.left = Math.round(LAY.tableLeft + LAY.tableW * 0.60 - i * 2) + 'px';
        c.style.top = Math.round(LAY.tableTop + LAY.tableH * 0.30 - i * 2) + 'px';
        piles.appendChild(c);
      }
    }
    const b1 = document.createElement('span');
    b1.className = 'tb-badge'; b1.style.left = Math.round(LAY.tableLeft + LAY.tableW * 0.40) + 'px'; b1.style.top = Math.round(LAY.tableTop + LAY.tableH * 0.38) + 'px'; b1.textContent = s.deck.length;
    const b2 = document.createElement('span');
    b2.className = 'tb-badge'; b2.style.left = Math.round(LAY.tableLeft + LAY.tableW * 0.60) + 'px'; b2.style.top = Math.round(LAY.tableTop + LAY.tableH * 0.38) + 'px'; b2.textContent = s.discard.length;
    piles.appendChild(b1); piles.appendChild(b2);

    // hand
    const me = Engine.byId(s, 'p0');
    const hand = $('tbHand'); hand.innerHTML = '';
    const n = me.hand.length;
    me.hand.forEach(function (c, i) {
      const off = i - (n - 1) / 2;
      const el = cardImg(c, 'tb-card' + (TB.sel === c.id ? ' sel' : ''));
      const lift = TB.sel === c.id ? -3 : 0;
      el.style.transform = 'translateX(' + (off * 66) + 'px) translateY(' +
        (Math.abs(off) * Math.abs(off) * 0.6 + lift) + 'cqw) rotate(' + (off * 8) + 'deg)';
      el.style.zIndex = 10 + i;
      el.onclick = function () { onCardTap(c); };
      hand.appendChild(el);
    });

    updateBidUI();
    const myTurn = s.phase === 'bid' && s.actor === 'p0';
    ['tbMin','tb2x','tbAllin','tbMinus','tbPlus','tbBid'].forEach(function (id) { $(id).disabled = !myTurn; });
    const showBid = (s.phase === 'bid' || s.phase === 'roundStart');
    $('tbBanner').style.display = showBid ? 'none' : 'block';
    $('tbBidVal').style.display = showBid ? 'block' : 'none';
    $('tbBanner').textContent = s.phase === 'select' ? 'Pick a Card'
      : s.phase === 'payout' ? 'Reveal!' : (phaseWord(s.phase) || 'Place Your Bid');
  }

  function updateBidUI() {
    const s = TB.s; if (!s) return;
    const me = Engine.byId(s, 'p0');
    const myTurn = s.phase === 'bid' && s.actor === 'p0';
    let rng = null;
    try { rng = Engine.legalBidRange(s, 'p0'); } catch (e) { rng = null; }
    if (!rng || !isFinite(rng.min) || !isFinite(rng.max)) {
      rng = { min: 100, max: Math.max(100, Math.round(me ? me.cash : 100)) };
    }
    if (TB.bid == null || !isFinite(TB.bid) || TB.bid < rng.min) TB.bid = rng.min;
    TB.bid = Math.max(rng.min, Math.min(rng.max, TB.bid));
    $('tbBidVal').textContent = 'Your Bid: ' + Math.round(TB.bid).toLocaleString('en-IN');
    const t = Math.max(0, Math.min(1, (TB.bid - rng.min) / Math.max(1, rng.max - rng.min)));
    const sl = $('tbSlider');
    sl.style.setProperty('--p', t.toFixed(4));
    $('tbFill').style.width = 'calc(32px + var(--p) * (100% - 64px))';
    $('tbKnob').style.left = 'calc(32px + var(--p) * (100% - 64px))';
    $('tbMinV').textContent = rng.min.toLocaleString('en-IN');
    $('tb2xV').textContent = Math.min(rng.max, rng.min * 2).toLocaleString('en-IN');
    $('tbAllinV').textContent = rng.max.toLocaleString('en-IN');
    ['tbMin','tb2x','tbAllin','tbMinus','tbPlus','tbBid'].forEach(function (id) {
      const el = $(id); if (el) el.disabled = !myTurn;
    });
  }

  function renderGoldPrice(s) {
    const price = Math.round(s.goldPrice);
    const el = $('tbGold'), tr = $('tbTri');
    if (TB_GOLD_SHOWN === null) TB_GOLD_SHOWN = price;
    if (TB_GOLD_SHOWN !== price) {
      cancelAnimationFrame(TB_GOLD_ANIM);
      const from = TB_GOLD_SHOWN, to = price, t0 = performance.now();
      (function step(now) {
        const k = Math.min(1, (now - t0) / 420);
        TB_GOLD_SHOWN = Math.round(from + (to - from) * k);
        el.textContent = TB_GOLD_SHOWN.toLocaleString('en-IN');
        if (k < 1) TB_GOLD_ANIM = requestAnimationFrame(step);
      })(t0);
    } else el.textContent = price.toLocaleString('en-IN');
    const prev = TB.prevGold;
    tr.classList.remove('hide', 'down');
    if (prev == null || price === prev) tr.classList.add('hide');
    else if (price < prev) tr.classList.add('down');
    if (s.round !== TB.goldRound) { TB.prevGold = price; TB.goldRound = s.round; }
  }

  function onCardTap(c) {
    const s = TB.s;
    if (s.phase !== 'select' || s.actor !== 'p0') return;
    if (TB.sel !== c.id) { TB.sel = c.id; renderTable(); return; }
    Engine.playCard(s, 'p0', c.id);
    TB.sel = null;
    renderTable(); tbTick();
  }

  function tbTick() {
    clearTimeout(TB.timer);
    const s = TB.s; if (!s) return;
    const p = s.actor ? Engine.byId(s, s.actor) : null;
    if (s.phase === 'bid') {
      if (TB.revStarted) { TB.revStarted = false; TB.faceUp = false; }
      if (p && p.isBot) {
        TB.timer = setTimeout(function () { Engine.placeBid(s, p.id, Bots.bid(s, p)); renderTable(); tbTick(); }, 480);
      }
    } else if (s.phase === 'handReveal') {
      TB.timer = setTimeout(function () { Engine.revealDone(s); renderTable(); tbTick(); }, 850);
    } else if (s.phase === 'select' && p && p.isBot) {
      TB.timer = setTimeout(function () { Engine.playCard(s, p.id, Bots.pick(s, p)); renderTable(); tbTick(); }, 420);
    } else if (s.phase === 'payout') {
      if (!TB.revStarted) {
        TB.revStarted = true;
        TB.faceUp = false;
        renderTable();
        TB.timer = setTimeout(function () {
          TB.faceUp = true;
          renderTable();
          TB.timer = setTimeout(function () { showPayout(); }, 5000);
        }, 5000);
      }
    } else if (s.phase === 'roundEnd') {
      TB.timer = setTimeout(function () {
        if (Engine.activePlayers(s).length < 2 || s.round >= s.totalRounds) { Engine.finishGame(s); renderTable(); tbTick(); return; }
        Engine.nextRound(s);
        if (s.phase === 'roundStart') { renderTable(); openRoundStart(); return; }
        autoRoundStart(); renderTable(); tbTick();
      }, 700);
    } else if (s.phase === 'finalSell') {
      Engine.finishGame(s); renderTable(); tbTick();
    } else if (s.phase === 'gameEnd') {
      showGameOver();
    }
  }

  function showPayout() {
    const s = TB.s, m = s.lastMatch; if (!m) return;
    let html = '<h3>Reveal</h3>';
    m.entries.forEach(function (e) {
      const p = Engine.byId(s, e.pid);
      const won = m.winner === e.pid, canc = m.cancelled.indexOf(e.pid) >= 0;
      html += '<p>' + p.name + ' \u2014 ' + (won ? '<b>WINS</b>' : canc ? 'cancelled' : 'lost') + '</p>';
    });
    html += m.winner ? '<p>Pot ' + Math.round(m.pot) + ' + ' + Math.round(m.bonus) + '</p>'
                     : '<p>All tied \u2014 bids returned</p>';
    html += '<button id="tbPayOk">Continue</button>';
    $('tbObox').innerHTML = html; $('tbOverlay').hidden = false;
    $('tbPayOk').onclick = function () { $('tbOverlay').hidden = true; Engine.payoutDone(s); renderTable(); tbTick(); };
  }

  const CFG = { sound: true, music: true, speed: 'normal', rounds: 12 };
  let DBG_TAPS = 0, DBG_T = null;
  let RS = { tab: 'gold', qty: 1, sel: null, open: false };
  const PV = {
    rs:   { id: 'rsOv',   sheet: 'rsSheet',   layer: 'rsLayer',   W: 1108, H: 1419, x0: 7, y0: 0, vw: 1090, vh: 1342 },
    set:  { id: 'setOv',  sheet: 'setSheet',  layer: 'setLayer',  W: 971, H: 1620, x0: 8, y0: 6, vw: 955, vh: 1585 },
    how:  { id: 'howOv',  sheet: 'howSheet',  layer: 'howLayer',  W: 971, H: 1620, x0: 8, y0: 6, vw: 955, vh: 1585 },
    go:   { id: 'goOv',   sheet: 'goSheet',   layer: 'goLayer',   W: 971, H: 1620, x0: 8, y0: 6, vw: 955, vh: 1585 },
    leave:{ id: 'leaveOv',sheet: 'leaveSheet',layer: 'leaveLayer',W: 971, H: 1620, x0: 8, y0: 6, vw: 955, vh: 1585 }
  };

  function pvFit(k) {
    const c = PV[k];
    const sheet = $(c.sheet), layer = $(c.layer);
    if (!sheet || !layer) return;
    const vv = window.visualViewport;
    const vw = vv ? vv.width : window.innerWidth;
    const vh = vv ? vv.height : window.innerHeight;
    const sc = Math.min((0.92 * vw) / c.vw, (0.90 * vh) / c.vh);
    const left = (vw - c.vw * sc) / 2 - c.x0 * sc;
    const top = (vh - c.vh * sc) / 2 - c.y0 * sc;
    sheet.style.left = left + 'px';
    sheet.style.top = top + 'px';
    sheet.style.width = (c.W * sc) + 'px';
    sheet.style.height = (c.H * sc) + 'px';
    const img = sheet.querySelector('.pv-img');
    if (img) { img.style.width = (c.W * sc) + 'px'; img.style.height = (c.H * sc) + 'px'; }
    layer.style.transform = 'scale(' + sc + ')';
  }

  function openOv(k) {
    const c = PV[k]; if (!c) return;
    const el = $(c.id); el.hidden = false;
    requestAnimationFrame(function () { el.classList.add('in'); pvFit(k); });
  }
  function closeOv(k) {
    const c = PV[k]; if (!c) return;
    const el = $(c.id); el.classList.remove('in');
    setTimeout(function () { el.hidden = true; }, 190);
  }

  function bindStage2() {
    $('tbGear').onclick = function () { openSettings(); };
    $('setClose').onclick = function () { closeOv('set'); };
    $('howClose').onclick = function () { closeOv('how'); };
    $('leaveNo').onclick = function () { closeOv('leave'); };
    $('leaveYes').onclick = function () { closeOv('leave'); closeOv('set'); goHome(); };
    $('rsClose').onclick = closeRoundStart;
    $('rsStart').onclick = closeRoundStart;
    document.querySelectorAll('.pv-tab').forEach(function (b) {
      b.onclick = function () {
        const t = b.dataset.tab;
        if (t === 'loan' || t === 'topup') { toast('Coming soon'); return; }
        RS.tab = t; renderRoundStart();
      };
    });
    $('tbRound').style.pointerEvents = 'auto';
    $('tbRound').onclick = function () {
      DBG_TAPS++; clearTimeout(DBG_T);
      DBG_T = setTimeout(function () { DBG_TAPS = 0; }, 1200);
      if (DBG_TAPS >= 5) { DBG_TAPS = 0; $('dbgOv').hidden = false; }
    };
    $('dbgClose').onclick = function () { $('dbgOv').hidden = true; };
    $('dbgSkip').onclick = function () {
      $('dbgOv').hidden = true;
      if (!TB.s) return;
      TB.s.round = Math.min(TB.s.totalRounds, TB.s.round + 1);
      Engine.startRound(TB.s); openRoundStart(); renderTable();
    };
    $('dbgPrice').onclick = function () {
      $('dbgOv').hidden = true;
      if (!TB.s) return;
      const v = parseInt(prompt('Gold price 1000-5000', String(TB.s.goldPrice)), 10);
      if (!isNaN(v)) { TB.s.goldPrice = Math.max(1000, Math.min(5000, Math.round(v / 100) * 100)); renderTable(); }
    };
    $('dbgCash').onclick = function () {
      $('dbgOv').hidden = true;
      if (!TB.s) return;
      Engine.byId(TB.s, 'p0').cash += 5000; renderTable();
    };
  }

  function renderSettings() {
    const locked = !!(TB.s && TB.s.round > 1);
    const rows = [6, 12, 18, 24];
    $('setBody').innerHTML =
      '<div class="pv-row"><span>Sound</span><button class="pv-toggle' + (CFG.sound ? ' on' : '') + '" id="setSound"><i></i></button></div>' +
      '<div class="pv-row"><span>Music</span><button class="pv-toggle' + (CFG.music ? ' on' : '') + '" id="setMusic"><i></i></button></div>' +
      '<div class="pv-row"><span>Game speed</span><div class="pv-seg" id="setSpeed">' +
        '<b class="' + (CFG.speed === 'normal' ? 'on' : '') + '" data-v="normal">Normal</b>' +
        '<b class="' + (CFG.speed === 'fast' ? 'on' : '') + '" data-v="fast">Fast</b></div></div>' +
      '<div class="pv-row"><span>Rounds</span><div class="pv-seg' + (locked ? ' ro' : '') + '" id="setRounds">' +
        rows.map(function (r) { return '<b class="' + (CFG.rounds === r ? 'on' : '') + '" data-v="' + r + '">' + r + '</b>'; }).join('') +
        '</div></div>' +
      '<button class="pv-link" id="setHow">How to Play</button>' +
      '<button class="pv-red" id="setLeave">Leave Game</button>';
    $('setSound').onclick = function () { CFG.sound = !CFG.sound; renderSettings(); };
    $('setMusic').onclick = function () { CFG.music = !CFG.music; renderSettings(); };
    $('setSpeed').querySelectorAll('b').forEach(function (b) { b.onclick = function () { CFG.speed = b.dataset.v; renderSettings(); }; });
    $('setRounds').querySelectorAll('b').forEach(function (b) {
      b.onclick = function () {
        if (TB.s && TB.s.round > 1) { toast('Rounds locked after round 1'); return; }
        CFG.rounds = parseInt(b.dataset.v, 10); renderSettings();
      };
    });
    $('setHow').onclick = openHowTo;
    $('setLeave').onclick = function () { openOv('leave'); };
  }
  function openSettings() { renderSettings(); openOv('set'); }

  function openHowTo() {
    const lines = ['Bid at least 100.', 'Everyone shows their hand once per round.', 'Pick one card.',
      'Highest card wins, equal top cards cancel.',
      'Winner takes the bids plus half of any bid above 100 from the bank.',
      'At the end, sell your gold. The player with the most cash wins.'];
    $('howBody').innerHTML = lines.map(function (t, i) {
      return '<div class="pv-how"><i>' + (i + 1) + '</i><span>' + t + '</span></div>';
    }).join('');
    openOv('how');
  }

  function openRoundStart() {
    if (!TB.s) return;
    RS.tab = 'gold'; RS.qty = 1; RS.sel = null;
    $('rsTitle').textContent = 'Round ' + TB.s.round + ' Begins';
    openOv('rs'); RS.open = true;
    renderRoundStart();
    botsRoundStart();
  }
  function closeRoundStart() {
    closeOv('rs'); RS.open = false;
    const s = TB.s;
    if (s && s.phase === 'roundStart') {
      if (s.step === 'gold') Engine.endGoldTurn(s);
      autoRoundStart(); renderTable(); tbTick();
    }
  }

  function renderRoundStart() {
    const s = TB.s; if (!s) return;
    document.querySelectorAll('.pv-tab').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === RS.tab); });
    const act = document.querySelector('.pv-tab.on'), hl = $('rsHl');
    if (act) {
      hl.style.left = act.style.left; hl.style.top = act.style.top;
      hl.style.width = act.style.width; hl.style.height = act.style.height;
      hl.classList.add('on');
    }
    const me = Engine.byId(s, 'p0');
    const body = $('rsBody');
    const hist = s.priceHistory.slice(-12);
    const prev = hist.length > 1 ? hist[hist.length - 2].price : null;
    const change = prev != null ? s.goldPrice - prev : 0;
    if (RS.tab === 'gold') {
      const W = 900, H = 120;
      const n = hist.length > 1 ? hist.length - 1 : 1;
      const lo = Math.min.apply(null, hist.map(function (x) { return x.price; }));
      const hi = Math.max.apply(null, hist.map(function (x) { return x.price; }));
      const flat = (hi - lo) < 1;
      let d = '', dots = '', grid = '';
      hist.forEach(function (p, i) {
        const x = hist.length === 1 ? W / 2 : (i / n) * W;
        const y = flat ? H / 2 : H - ((p.price - lo) / (hi - lo)) * (H - 16) - 8;
        d += (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1);
        dots += '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="' +
          (i === hist.length - 1 ? 9 : 6) + '" fill="' + (i === hist.length - 1 ? '#c96a10' : '#e88b1e') + '"/>';
      });
      for (let i = 0; i <= 4; i++) grid += '<line x1="0" y1="' + (i * H / 4) + '" x2="' + W + '" y2="' + (i * H / 4) + '" stroke="rgba(160,120,60,.18)" stroke-width="2"/>';
      body.innerHTML =
        '<div class="pv-price"><img src="assets/game/ic-gold.webp" alt="">' + s.goldPrice.toLocaleString('en-IN') +
        (change ? ' <span class="pv-trend ' + (change > 0 ? 'up' : 'down') + '">' +
          (change > 0 ? '\u25B2 +' : '\u25BC ') + change.toLocaleString('en-IN') + '</span>' : '') + '</div>' +
        '<svg class="pv-graph" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none">' + grid +
        '<path d="' + d + '" fill="none" stroke="#e88b1e" stroke-width="4" stroke-linejoin="round"/>' + dots + '</svg>' +
        '<div class="pv-cols"><span><img src="assets/game/ic-gold.webp" alt="">My Gold: ' + me.gold + '</span>' +
        '<span><img src="assets/game/ic-cash1.webp" alt="">My Cash: ' + Math.round(me.cash).toLocaleString('en-IN') + '</span></div>' +
        '<div class="pv-step"><button id="rsMinus">\u2212</button><b id="rsQty">' + RS.qty + '</b><button id="rsPlus">+</button></div>' +
        '<div class="pv-btns"><button class="pv-buy" id="rsBuy">BUY</button><button class="pv-sell" id="rsSell">SELL</button></div>';
      $('rsMinus').onclick = function () { RS.qty = Math.max(1, RS.qty - 1); renderRoundStart(); };
      $('rsPlus').onclick = function () { RS.qty = Math.min(99, RS.qty + 1); renderRoundStart(); };
      $('rsBuy').onclick = function () {
        if (Engine.buyGold(s, 'p0', RS.qty)) { renderRoundStart(); renderTable(); } else toast('Not enough cash');
      };
      $('rsSell').onclick = function () {
        if (Engine.sellGold(s, 'p0', RS.qty)) { renderRoundStart(); renderTable(); } else toast('Not enough gold');
      };
    } else {
      const seen = {}, tiles = [];
      s.discard.forEach(function (c) {
        const k = c.r + ':' + c.s;
        if (seen[k]) { seen[k].n++; return; }
        seen[k] = { card: c, n: 1 }; tiles.push(seen[k]);
      });
      if (!tiles.length) {
        body.innerHTML = '<div class="pv-cols"><span><img src="assets/game/ic-cash1.webp" alt="">My Cash: ' +
          Math.round(me.cash).toLocaleString('en-IN') + '</span></div><div class="pv-empty">No cards in the discard pile yet</div>';
        return;
      }
      let html = '<div class="pv-cols"><span><img src="assets/game/ic-cash1.webp" alt="">My Cash: ' +
        Math.round(me.cash).toLocaleString('en-IN') + '</span></div><div class="pv-grid">';
      tiles.forEach(function (t) {
        html += '<div class="pv-card' + (RS.sel === t.card.id ? ' sel' : '') + '" data-id="' + t.card.id + '">' +
          '<img src="assets/game/' + cardFace(t.card.r, t.card.s) + '.webp" alt="">' +
          '<span class="pv-tag">' + Engine.priceOf(t.card) + '</span>' +
          (t.n > 1 ? '<b>x' + t.n + '</b>' : '') + '</div>';
      });
      html += '</div>';
      const selTile = tiles.filter(function (t) { return t.card.id === RS.sel; })[0];
      html += '<button class="pv-green" id="rsBuyCard">' +
        (selTile ? 'Buy for ' + Engine.priceOf(selTile.card) : 'Select a card') + '</button>';
      body.innerHTML = html;
      body.querySelectorAll('.pv-card').forEach(function (el) {
        el.onclick = function () { RS.sel = el.dataset.id; renderRoundStart(); };
      });
      $('rsBuyCard').onclick = function () {
        if (!RS.sel) return;
        if (me.hand.length >= Math.max(5, s.players.length) + 1) { toast('Hand is full'); return; }
        if (Engine.buyDiscardCard(s, 'p0', RS.sel)) { RS.sel = null; renderRoundStart(); renderTable(); }
        else toast('Not enough cash');
      };
    }
  }

  function botsRoundStart() {
    const s = TB.s; if (!s) return;
    const prev = s.priceHistory.length > 1 ? s.priceHistory[s.priceHistory.length - 2].price : null;
    const change = prev != null ? s.goldPrice - prev : 0;
    s.players.forEach(function (p) {
      if (!p.isBot || p.eliminated || s.phase !== 'roundStart') return;
      if (change <= -300 && p.cash > 1000) {
        const budget = Math.min(p.cash - 1000, p.cash * 0.25);
        const q = Math.floor(budget / s.goldPrice);
        if (q > 0) Engine.buyGold(s, p.id, q);
      } else if (change >= 400 && p.gold > 0) {
        const q = Math.floor(p.gold / 2);
        if (q > 0) Engine.sellGold(s, p.id, q);
      }
      const big = s.discard.filter(function (c) { return (c.r === 13 || c.r === 14) && Engine.priceOf(c) <= p.cash; })[0];
      if (big) Engine.buyDiscardCard(s, p.id, big.id);
    });
  }

  function showGameOver() {
    const s = TB.s;
    s.players.forEach(function (p) { if (p.gold > 0) { p.cash += p.gold * s.goldPrice; p.gold = 0; } });
    const rows = s.players.map(function (p) {
      return { name: p.name, cash: p.cash, profit: p.cash - s.startingCash, me: p.id === 'p0' };
    }).sort(function (a, b) { return b.cash - a.cash; });
    $('goBody').innerHTML = rows.map(function (r, i) {
      return '<div class="pv-go' + (r.me ? ' me' : '') + '"><span>' + (i + 1) + '</span>' +
        '<span class="av">' + r.name.charAt(0) + '</span><span class="nm">' + r.name + '</span>' +
        '<span>' + Math.round(r.cash).toLocaleString('en-IN') + '</span>' +
        '<span class="' + (r.profit >= 0 ? 'pz' : 'nz') + '">' + (r.profit >= 0 ? '+' : '') +
        Math.round(r.profit).toLocaleString('en-IN') + '</span></div>';
    }).join('') + '<button class="pv-green" id="goHome">Home</button>';
    $('goHome').onclick = function () { closeOv('go'); goHome(); };
    openOv('go');
  }

  function phaseWord(p) {
    return { handReveal: 'Revealing', payout: 'Reveal!', roundEnd: 'Round Over',
             gameEnd: 'Game Over', finalSell: 'Final Sale' }[p] || '';
  }

  function renderGoldPrice(s) {
    const price = Math.round(s.goldPrice);
    const el = $('tbGold'), tr = $('tbTri');
    if (TB_GOLD_SHOWN === null) TB_GOLD_SHOWN = price;
    if (TB_GOLD_SHOWN !== price) {
      cancelAnimationFrame(TB_GOLD_ANIM);
      const from = TB_GOLD_SHOWN, to = price, t0 = performance.now();
      (function step(now) {
        const k = Math.min(1, (now - t0) / 420);
        TB_GOLD_SHOWN = Math.round(from + (to - from) * k);
        el.textContent = TB_GOLD_SHOWN.toLocaleString('en-IN');
        if (k < 1) TB_GOLD_ANIM = requestAnimationFrame(step);
      })(t0);
    } else el.textContent = price.toLocaleString('en-IN');
    const prev = TB.prevGold;
    tr.classList.remove('hide', 'down');
    if (prev == null || price === prev) tr.classList.add('hide');
    else if (price < prev) tr.classList.add('down');
    $('tbGold').textContent = price.toLocaleString('en-IN') +
      (prev != null && price !== prev ? '  ' + (price > prev ? '\u25B2 +' : '\u25BC ') + (price - prev).toLocaleString('en-IN') : '');
    if (prev != null && price !== prev) { tr.classList.remove('pop'); void tr.offsetWidth; tr.classList.add('pop'); }
    if (s.round !== TB.goldRound) { TB.prevGold = price; TB.goldRound = s.round; }
  }

  function onCardTap(c) {
    const s = TB.s;
    if (s.phase !== 'select' || s.actor !== 'p0') return;
    if (TB.sel !== c.id) { TB.sel = c.id; renderTable(); return; }
    Engine.playCard(s, 'p0', c.id);
    TB.sel = null;
    renderTable(); tbTick();
  }

  function tbTick() {
    clearTimeout(TB.timer);
    const s = TB.s; if (!s) return;
    const p = s.actor ? Engine.byId(s, s.actor) : null;
    if (s.phase === 'bid') {
      if (TB.revStarted) { TB.revStarted = false; TB.faceUp = false; }
      if (p && p.isBot) {
        TB.timer = setTimeout(function () { Engine.placeBid(s, p.id, Bots.bid(s, p)); renderTable(); tbTick(); }, 480);
      }
    } else if (s.phase === 'handReveal') {
      TB.timer = setTimeout(function () { Engine.revealDone(s); renderTable(); tbTick(); }, 850);
    } else if (s.phase === 'select' && p && p.isBot) {
      TB.timer = setTimeout(function () { Engine.playCard(s, p.id, Bots.pick(s, p)); renderTable(); tbTick(); }, 420);
    } else if (s.phase === 'payout') {
      if (!TB.revStarted) {
        TB.revStarted = true;
        TB.faceUp = false;
        renderTable();
        TB.timer = setTimeout(function () {
          TB.faceUp = true;
          renderTable();
          TB.timer = setTimeout(function () { showPayout(); }, 5000);
        }, 5000);
      }
    } else if (s.phase === 'roundEnd') {
      TB.timer = setTimeout(function () {
        if (Engine.activePlayers(s).length < 2 || s.round >= s.totalRounds) { Engine.finishGame(s); renderTable(); tbTick(); return; }
        Engine.nextRound(s);
        if (s.phase === 'roundStart') { renderTable(); openRoundStart(); return; }
        autoRoundStart(); renderTable(); tbTick();
      }, 700);
    } else if (s.phase === 'finalSell') {
      Engine.finishGame(s); renderTable(); tbTick();
    } else if (s.phase === 'gameEnd') {
      showGameOver();
    }
  }

  function showPayout() {
    const s = TB.s, m = s.lastMatch; if (!m) return;
    let html = '<h3>Reveal</h3>';
    m.entries.forEach(function (e) {
      const p = Engine.byId(s, e.pid);
      const won = m.winner === e.pid, canc = m.cancelled.indexOf(e.pid) >= 0;
      html += '<p>' + p.name + ' \u2014 ' + (won ? '<b>WINS</b>' : canc ? 'cancelled' : 'lost') + '</p>';
    });
    html += m.winner ? '<p>Pot ' + Math.round(m.pot) + ' + ' + Math.round(m.bonus) + '</p>'
                     : '<p>All tied \u2014 bids returned</p>';
    html += '<button id="tbPayOk">Continue</button>';
    $('tbObox').innerHTML = html; $('tbOverlay').hidden = false;
    $('tbPayOk').onclick = function () { $('tbOverlay').hidden = true; Engine.payoutDone(s); renderTable(); tbTick(); };
  }

  function showEnd() {
    const s = TB.s, rows = s.results ? s.results.rows : [];
    let html = '<h3>Game Over</h3>';
    rows.forEach(function (r, i) { html += '<p>' + (i + 1) + '. ' + r.name + ' \u2014 ' + Math.round(r.cash).toLocaleString('en-IN') + '</p>'; });
    html += '<button id="tbEndOk">Back to Home</button>';
    $('tbObox').innerHTML = html; $('tbOverlay').hidden = false;
    $('tbEndOk').onclick = function () { $('tbOverlay').hidden = true; goHome(); };
  }

  function bindTable() {
    $('lobbyStart').onclick = startTable;
    $('tbMinus').onclick = function () { nudgeBid(-100); };
    $('tbPlus').onclick = function () { nudgeBid(100); };
    $('tbMin').onclick = function () { setBid('min'); };
    $('tb2x').onclick = function () { setBid('2x'); };
    $('tbAllin').onclick = function () { setBid('all'); };
    $('tbBid').onclick = function () {
      const s = TB.s;
      if (!s || s.phase !== 'bid' || s.actor !== 'p0') return;
      if (Engine.placeBid(s, 'p0', TB.bid)) { renderTable(); tbTick(); }
    };
    const sl = $('tbSlider');
    function setFromEvent(ev) {
      const s = TB.s;
      if (!s || s.phase !== 'bid' || s.actor !== 'p0') return;
      const rng = Engine.legalBidRange(s, 'p0');
      const b = sl.getBoundingClientRect();
      const t = Math.max(0, Math.min(1, (ev.clientX - b.left) / b.width));
      TB.bid = Math.round((rng.min + t * (rng.max - rng.min)) / 100) * 100;
      updateBidUI();
    }
    let drag = false;
    sl.addEventListener('pointerdown', function (e) { drag = true; setFromEvent(e); });
    sl.addEventListener('pointermove', function (e) { if (drag) setFromEvent(e); });
    sl.addEventListener('pointerup', function () { drag = false; });
    sl.addEventListener('pointercancel', function () { drag = false; });
    window.addEventListener('resize', function () { fitTable(); updateBidUI(); });
    window.addEventListener('orientationchange', function () { setTimeout(fitTable, 120); });
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', function () { fitTable(); updateBidUI(); });
      window.visualViewport.addEventListener('scroll', fitTable);
    }
    if (window.visualViewport) window.visualViewport.addEventListener('resize', fitTable);
  }

  function nudgeBid(d) {
    const s = TB.s;
    if (!s || s.phase !== 'bid' || s.actor !== 'p0') return;
    const rng = Engine.legalBidRange(s, 'p0');
    TB.bid = Math.max(rng.min, Math.min(rng.max, TB.bid + d));
    updateBidUI();
  }
  function setBid(k) {
    const s = TB.s;
    if (!s || s.phase !== 'bid' || s.actor !== 'p0') return;
    const rng = Engine.legalBidRange(s, 'p0');
    TB.bid = k === 'min' ? rng.min : k === '2x' ? Math.min(rng.max, rng.min * 2) : rng.max;
    updateBidUI();
  }

  function bindTableSelect() {
    $('ts-back').onclick = function () { goHome(); };
    $('ts-rookie').onclick = function () { selectTier('rookie'); };
    $('ts-pro').onclick = function () { selectTier('pro'); };
    $('ts-high').onclick = function () { selectTier('high'); };
    $('ts-ranked').onclick = function () { toast('Coming soon'); };
    $('ts-friendly').onclick = function () { TS.mode = 'friendly'; renderTableSelect(); };
    $('ts-continue').onclick = openBuyIn;
    document.querySelectorAll('.pn').forEach(function (b) {
      b.onclick = function () { TS.players = +b.dataset.n; renderTableSelect(); };
    });
    const track = $('biTrack');
    function setFromEvent(ev) {
      const inner = $('biInner').getBoundingClientRect();
      const k = inner.width / 1122;
      const r = buyInRange();
      const x = (ev.clientX - inner.left) / k;
      const t = Math.max(0, Math.min(1, (x - 215) / 690));
      TS.amountTouched = true;
      TS.amount = Math.round((r.min + t * (r.max - r.min)) / 100) * 100;
      renderBuyIn();
    }
    let dragging = false;
    track.addEventListener('pointerdown', function (ev) { dragging = true; setFromEvent(ev); track.setPointerCapture(ev.pointerId); });
    track.addEventListener('pointermove', function (ev) { if (dragging) setFromEvent(ev); });
    track.addEventListener('pointerup', function () { dragging = false; });
    track.addEventListener('pointercancel', function () { dragging = false; });

    function holdRepeat(el, delta) {
      let t1 = null, t2 = null;
      function stop() { clearTimeout(t1); clearInterval(t2); }
      el.addEventListener('pointerdown', function () {
        nudgeAmount(delta);
        t1 = setTimeout(function () { t2 = setInterval(function () { nudgeAmount(delta); }, 90); }, 380);
      });
      ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (e) { el.addEventListener(e, stop); });
    }
    holdRepeat($('biMinus'), -100);
    holdRepeat($('biPlus'), 100);

    $('biChip1').onclick = function () { TS.amountTouched = true; TS.amount = 1000; renderBuyIn(); };
    $('biChip2').onclick = function () { TS.amountTouched = true; TS.amount = 2000; renderBuyIn(); };
    $('biChipMax').onclick = function () { TS.amountTouched = true; TS.amount = buyInRange().max; renderBuyIn(); };
    $('biJoin').onclick = joinTable;
    $('biCancel').onclick = closeBuyIn;
    $('biClose').onclick = closeBuyIn;
    $('lobbyHome').onclick = function () { goHome(); };
    bindTable();
    bindStage2();
    setInterval(function () {
      TS.counts = TS.counts.map(function (c) {
        return Math.max(3, c + (Math.random() < 0.5 ? -1 : 1) * Math.floor(Math.random() * 3));
      });
      if (!$('tableSelectScreen').hidden) setCounts();
    }, 3200);
  }

  function syncModeSeg() {
    document.querySelectorAll('#modeSeg button').forEach(function (x) {
      x.classList.toggle('on', x.dataset.mode === UI.mode);
    });
    refreshMenu();
  }

  function openSetup() {
    refreshMenu();
    showScreen('menu');
  }

  function showHomeProfile() {
    openSheet(
      '<div class="sh-head">Profile</div>' +
      '<div class="sh-body">' +
      '<div class="kv"><span>Name</span><b>' + esc(PROFILE.name) + '</b></div>' +
      '<div class="kv"><span>Level</span><b>' + PROFILE.level + '</b></div>' +
      '<div class="kv"><span>XP</span><b>' + PROFILE.xp + ' / ' + PROFILE.xpMax + '</b></div>' +
      '<div class="kv"><span>Cash</span><b>' + fmt(PROFILE.cash) + '</b></div>' +
      '<div class="kv"><span>RIX</span><b>' + PROFILE.rix + '</b></div>' +
      '</div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="hpC">Close</button></div>', 'log-sheet', 'generic');
    $('hpC').onclick = closeSheet;
  }

  function showHomeLeaderboard() {
    const rows = [
      { n: 'RajaBhai', v: 12450 },
      { n: 'BiscuitOP', v: 15230 },
      { n: 'PixelRani', v: 11320 },
      { n: 'LegendMithu', v: 9870 },
      { n: PROFILE.name, v: PROFILE.cash }
    ].sort(function (a, b) { return b.v - a.v; });
    openSheet(
      '<div class="sh-head">Leaderboard <span class="sh-price">net worth</span></div>' +
      '<div class="sh-body"><div class="standlist">' + rows.map(function (r, i) {
        return '<div class="stand' + (i === 0 ? ' first' : '') + '"><span class="pos">' + (i + 1) + '</span>' +
          '<span class="nm">' + esc(r.n) + '</span><span class="cs">' + fmt(r.v) + '</span><span class="gd"></span></div>';
      }).join('') + '</div></div>' +
      '<div class="sh-foot"><button class="btn primary wide" id="hlC">Close</button></div>', 'log-sheet', 'generic');
    $('hlC').onclick = closeSheet;
  }
  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();

  window.GOW = { get state() { return S; }, UI: UI, Engine: E, TB: TB, TS: TS, rerender: renderTable, openRS: openRoundStart, goOver: showGameOver };
})();
