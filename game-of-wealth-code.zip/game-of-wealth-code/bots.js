/* =====================================================================
   BOT AI — sits on top of the engine, reads state, returns a decision.
   Easy  : random.
   Normal: bids by hand strength, buys gold low / sells high.
   Hard  : also tracks the Cards Space and plays around the cards left.
   ===================================================================== */
const Bots = (function () {
  'use strict';

  function rng(s) { return s.rng(); }
  function randInt(s, a, b) { return a + Math.floor(rng(s) * (b - a + 1)); }

  function handStrength(hand) {
    if (!hand.length) return 0;
    const ranks = hand.map(c => c.r).sort((a, b) => b - a);
    const top = ranks.slice(0, 2);
    const avg = top.reduce((a, b) => a + b, 0) / top.length;
    return Math.max(0, Math.min(1, (avg - 2) / 12));
  }

  /* highest rank still live in opponents' hands (all hands were revealed) */
  function bestOpponentRank(s, p) {
    let m = 0;
    s.players.forEach(o => {
      if (o.id !== p.id && !o.eliminated && s.matchPlayers.indexOf(o.id) >= 0) {
        o.hand.forEach(c => { if (c.r > m) m = c.r; });
        const played = s.plays[o.id];
        if (played && played.r > m) m = played.r;
      }
    });
    return m;
  }

  /* how many high cards are already dead in the Cards Space */
  function discardPressure(s) {
    let high = 0;
    s.discard.forEach(c => { if (c.r >= 12) high++; });
    return high;
  }

  /* ---------------- gold ---------------- */
  function goldMove(s, p) {
    const price = s.goldPrice;
    const hist = s.priceHistory.map(h => h.price);
    const avg = hist.reduce((a, b) => a + b, 0) / hist.length;
    const lvl = p.bot;

    if (lvl === 'easy') {
      const r = rng(s);
      if (r < 0.18 && p.gold > 0) return { sell: Math.max(1, Math.floor(p.gold * 0.5)) };
      if (r < 0.40 && p.cash > 600) {
        const q = Math.max(1, Math.floor((p.cash * 0.25) / price));
        return { buy: q };
      }
      return null;
    }

    const cheapAt = lvl === 'hard' ? 0.94 : 0.90;
    const dearAt = lvl === 'hard' ? 1.08 : 1.15;

    if (price >= avg * dearAt && p.gold > 0) {
      return { sell: p.gold };
    }
    if (price <= avg * cheapAt && p.cash > 500) {
      const reserve = lvl === 'hard' ? 400 : 600;
      const budget = Math.max(0, p.cash - reserve);
      const q = Math.floor(budget / price);
      if (q > 0) return { buy: q };
    }
    // hard bot also buys a little when the trend is clearly up
    if (lvl === 'hard' && s.goldTrend > 0 && price < avg * 1.02 && p.cash > 900) {
      const q = Math.floor((p.cash - 800) / price);
      if (q > 0) return { buy: Math.max(1, Math.floor(q * 0.6)) };
    }
    return null;
  }

  /* ---------------- buying from the Cards Space ---------------- */
  function cardWish(s, p) {
    if (p.hand.length >= Engine.HAND_LIMIT) return null;
    const lvl = p.bot;
    const affordable = s.discard.filter(c => Engine.priceOf(c) <= p.cash);
    if (!affordable.length) return null;
    if (lvl === 'easy') {
      if (rng(s) < 0.45) return affordable[Math.floor(rng(s) * affordable.length)];
      return null;
    }
    const sorted = affordable.slice().sort((a, b) => b.r - a.r);
    const best = sorted[0];
    const reserve = lvl === 'hard' ? 300 : 500;
    if (best.r < (lvl === 'hard' ? 11 : 12)) return null;
    if (p.cash - Engine.priceOf(best) < reserve) return null;
    if (p.hand.length >= 6) return null;
    return best;
  }

  /* ---------------- bidding ---------------- */
  function bid(s, p) {
    const cash = Math.floor(p.cash);
    if (cash < Engine.MIN_BID) return null;
    const lvl = p.bot;
    // hard rule: bid = 100 * k, k in [1, floor(cash/100)], and <= 40% of cash
    const maxUnits = Math.floor(cash / 100);
    const capUnits = Math.max(1, Math.min(maxUnits, Math.floor((cash * 0.40) / 100)));
    if (capUnits < 1) return null;

    if (lvl === 'easy') {
      return 100 * randInt(s, 1, Math.min(capUnits, 4));
    }

    const strength = handStrength(p.hand);
    let units = Math.round(1 + Math.pow(strength, 1.4) * (capUnits - 1));

    if (lvl === 'hard') {
      const dead = discardPressure(s);
      units = Math.round(units * (1 + Math.min(0.25, dead * 0.04)));
    }
    // a little noise so bots are not readable, still on the 100 grid
    units = Math.round(units * (0.9 + rng(s) * 0.2));
    units = Math.max(1, Math.min(capUnits, units));
    return 100 * units;
  }

  /* ---------------- card selection ---------------- */
  function pick(s, p) {
    const hand = p.hand.slice();
    if (!hand.length) return null;
    const lvl = p.bot;

    if (lvl === 'easy') return hand[Math.floor(rng(s) * hand.length)].id;

    const byRankAsc = hand.slice().sort((a, b) => a.r - b.r);

    if (lvl === 'hard') {
      const oppMax = bestOpponentRank(s, p);
      const winning = byRankAsc.filter(c => c.r > oppMax);
      if (winning.length) return winning[0].id;   // cheapest card that beats them all
      // can't win: dump the lowest card and keep the big ones
      return byRankAsc[0].id;
    }

    // normal: play strong, occasionally sandbag
    const r = rng(s);
    if (r < 0.72) return byRankAsc[byRankAsc.length - 1].id;
    if (r < 0.9 && byRankAsc.length > 1) return byRankAsc[byRankAsc.length - 2].id;
    return byRankAsc[0].id;
  }

  /* ---------------- loans ---------------- */
  function loanRequest(s, p) {
    const need = Engine.MIN_BID - p.cash;
    const bankMax = Engine.bankLoanMax(s, p.id);
    const lvl = p.bot;
    if (lvl === 'easy') {
      if (bankMax >= need && rng(s) < 0.8) return { lender: 'bank', amount: Math.max(need, Math.min(bankMax, 200)) };
      return { decline: true };
    }
    // aim for a working stack, not just the bare minimum
    const target = Math.min(bankMax, Math.max(need, Math.round((p.cash + 600) / 100) * 100));
    if (bankMax >= need) return { lender: 'bank', amount: target };
    const others = Engine.loanOptions(s, p.id).filter(o => o.id !== 'bank' && o.max >= need);
    if (others.length) {
      others.sort((a, b) => b.max - a.max);
      return { lender: others[0].id, amount: Math.min(others[0].max, Math.max(need, 400)) };
    }
    return { decline: true };
  }

  function loanOffer(s, lender, borrowerId, amount) {
    const lvl = lender.bot;
    if (lvl === 'easy') return rng(s) < 0.6;
    if (lvl === 'hard') return lender.cash - amount > 300;
    return lender.cash - amount > 500;
  }

  /* ---------------- final sale ---------------- */
  function finalSale(s, p) {
    const hist = s.priceHistory.map(h => h.price);
    const avg = hist.reduce((a, b) => a + b, 0) / hist.length;
    if (p.gold === 0) return 0;
    if (p.bot === 'easy') return rng(s) < 0.7 ? p.gold : 0;
    if (p.bot === 'hard') return s.goldPrice >= avg ? p.gold : Math.floor(p.gold * 0.6);
    return p.gold;
  }

  return {
    handStrength: handStrength,
    goldMove: goldMove,
    cardWish: cardWish,
    bid: bid,
    pick: pick,
    loanRequest: loanRequest,
    loanOffer: loanOffer,
    finalSale: finalSale
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = Bots;
