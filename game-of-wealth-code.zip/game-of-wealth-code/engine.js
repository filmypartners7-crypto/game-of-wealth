/* =====================================================================
   GAME OF WEALTH — PURE ENGINE
   No DOM, no timers, no globals mutated outside the state object.
   Every random draw goes through state.rng (seeded) so a game is
   fully reproducible and the same engine can drive a server later.
   ===================================================================== */
const Engine = (function () {
  'use strict';

  /* ---------- constants ---------- */
  const RANKS = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
  const RANK_LABEL = { 2:'2',3:'3',4:'4',5:'5',6:'6',7:'7',8:'8',9:'9',10:'10',11:'J',12:'Q',13:'K',14:'A' };
  const SUITS = ['\u2660', '\u2665', '\u2666', '\u2663'];
  const CARD_PRICE = { 2:50,3:75,4:100,5:125,6:150,7:175,8:200,9:225,10:250,11:300,12:500,13:700,14:1000 };

  const MIN_BID = 100;
  const HAND_REFILL = 5;   // floor; actual hand size = max(5, playerCount)
  const HAND_LIMIT = 7;
  const BANK_LOAN_CAP = 2000;
  const GOLD_MIN = 1000;
  const GOLD_MAX = 5000;
  const GOLD_START = 1000;

  /* ---------- tiny helpers ---------- */
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function shuffle(arr, rng) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      const t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const money = (n) => Math.round(n).toLocaleString('en-IN');

  function activePlayers(s) { return s.players.filter(p => !p.eliminated); }
  function byId(s, id) { return s.players.find(p => p.id === id) || null; }
  function cardLabel(c) { return RANK_LABEL[c.r] + SUITS[c.s]; }
  function cardName(c) { return RANK_LABEL[c.r]; }
  function priceOf(c) { return CARD_PRICE[c.r]; }

  function log(s, text, kind) {
    s.log.unshift({ round: s.round, text: text, kind: kind || 'info', n: ++s.logSeq });
    if (s.log.length > 260) s.log.pop();
  }

  /* ---------- new game ---------- */
  function newGame(opts) {
    opts = opts || {};
    const players = opts.players || [{ name: 'You', isBot: false }];
    const startingCash = opts.startingCash != null ? opts.startingCash : 2000;
    const seed = (opts.seed != null) ? opts.seed : (Date.now() >>> 0);
    const rng = mulberry32(seed >>> 0);

    const rounds = opts.rounds != null ? opts.rounds : 12;
    const N = players.length;
    const H = Math.max(HAND_REFILL, N);
    const needed = N * H + (rounds - 1) * N * N;
    const decksN = Math.max(1, Math.ceil(needed / 52));
    let cid = 0;
    const deck = [];
    for (let d = 0; d < decksN; d++) {
      for (let sIdx = 0; sIdx < 4; sIdx++) {
        for (let r = 0; r < RANKS.length; r++) deck.push({ id: 'c' + (cid++), r: RANKS[r], s: sIdx });
      }
    }
    shuffle(deck, rng);

    const ps = players.map((p, i) => ({
      id: 'p' + i,
      seat: i,
      name: p.name || ('Player ' + (i + 1)),
      isBot: !!p.isBot,
      bot: p.bot || 'normal',
      cash: startingCash,
      gold: 0,
      hand: [],
      eliminated: false,
      wins: 0,
      spent: 0,
      goldBought: 0,
      goldSold: 0
    }));

    const s = {
      seed: seed,
      rng: rng,
      startingCash: startingCash,
      totalRounds: rounds,
      decks: decksN,
      players: ps,
      deck: deck,
      discard: [],
      bank: { cash: 200000 },
      goldPrice: GOLD_START,
      goldTrend: 0,
      priceHistory: [{ round: 1, price: GOLD_START }],
      round: 1,
      matchIndex: 0,
      matchesThisRound: 0,
      phase: 'idle',
      step: null,
      queue: [],
      queueIdx: 0,
      actor: null,
      matchPlayers: [],
      bids: {},
      plays: {},
      lastMatch: null,
      loans: [],
      loanQueue: [],
      loanIdx: 0,
      loanPending: null,
      log: [],
      logSeq: 0,
      roundEndInfo: null,
      results: null,
      finished: false,
      version: 1
    };

    ps.forEach(p => {
      const hs = Math.max(HAND_REFILL, s.players.length);
      for (let i = 0; i < hs; i++) p.hand.push(s.deck.pop());
    });

    log(s, 'Table opened. Each player starts with ' + money(startingCash) + ' cash and 5 cards.', 'good');
    startRound(s);
    return s;
  }

  /* ---------- gold market ---------- */
  function rollGoldPrice(s) {
    const p = s.goldPrice;
    let trend = s.goldTrend || 1;
    if (s.rng() < 0.25) trend = -trend;                    // momentum flips 25% of rounds
    let np;
    if (s.rng() < 0.10) {                                  // 10% spike or crash
      const up = s.rng() < 0.5;
      const mag = 1000 + Math.floor(s.rng() * 11) * 100;   // 1000..2000
      np = p + (up ? mag : -mag);
    } else {
      np = p + trend * 300 + Math.round((s.rng() * 800 - 400) / 100) * 100;
    }
    np = clamp(Math.round(np / 100) * 100, GOLD_MIN, GOLD_MAX);
    if (np === p) np = clamp(p + trend * 100, GOLD_MIN, GOLD_MAX);
    s.goldTrend = trend;
    return np;
  }

  function startRound(s) {
    if (s.finished) return s;
    s.matchIndex = 0;
    s.bids = {}; s.plays = {}; s.lastMatch = null; s.roundEndInfo = null;
    // A round is N matches (N = active players). A hand only holds 5 cards and
    // one card is spent per match, so the round is capped at 5 matches to keep
    // every seat able to play every match of the round.
    s.matchesThisRound = activePlayers(s).length;

    if (s.round > 1) {
      const prev = s.goldPrice;
      const np = rollGoldPrice(s);
      s.goldPrice = np;
      s.priceHistory.push({ round: s.round, price: np });
      const dir = np > prev ? 'up' : (np < prev ? 'down' : 'flat');
      log(s, 'Gold ' + (dir === 'up' ? '\u25B2' : dir === 'down' ? '\u25BC' : '\u25AC') +
        ' ' + money(np) + ' per biscuit (was ' + money(prev) + ').', dir === 'up' ? 'gold' : 'gold');
    } else {
      log(s, 'Round 1. Gold opens at ' + money(s.goldPrice) + ' per biscuit.', 'gold');
    }

    s.phase = 'roundStart';
    s.step = 'gold';
    s.queue = activePlayers(s).map(p => p.id);
    s.queueIdx = 0;
    s.actor = s.queue[0] || null;
    return s;
  }

  /* ---------- step 2: gold trading ---------- */
  function buyGold(s, pid, qty) {
    const p = byId(s, pid);
    qty = Math.floor(qty);
    if (!p || p.eliminated || s.phase !== 'roundStart' || s.step !== 'gold') return false;
    if (qty <= 0) return false;
    const cost = qty * s.goldPrice;
    if (cost > p.cash) return false;
    p.cash -= cost;
    p.gold += qty;
    p.goldBought += qty;
    s.bank.cash += cost;
    log(s, p.name + ' bought ' + qty + ' gold @ ' + money(s.goldPrice) + ' for ' + money(cost) + '.', 'gold');
    return true;
  }

  function sellGold(s, pid, qty) {
    const p = byId(s, pid);
    qty = Math.floor(qty);
    if (!p || p.eliminated || s.phase !== 'roundStart' || s.step !== 'gold') return false;
    if (qty <= 0 || qty > p.gold) return false;
    const gain = qty * s.goldPrice;
    p.gold -= qty;
    p.cash += gain;
    p.goldSold += qty;
    s.bank.cash -= gain;
    log(s, p.name + ' sold ' + qty + ' gold @ ' + money(s.goldPrice) + ' for ' + money(gain) + '.', 'gold');
    return true;
  }

  function endGoldTurn(s) {
    if (s.step !== 'gold') return s;
    s.queueIdx++;
    if (s.queueIdx < s.queue.length) {
      s.actor = s.queue[s.queueIdx];
    } else {
      beginCardStep(s);
    }
    return s;
  }

  /* ---------- step 3: buying from the Cards Space ---------- */
  function beginCardStep(s) {
    s.step = 'cards';
    s.queue = activePlayers(s).map(p => p.id);
    s.queueIdx = 0;
    s.actor = s.queue[0] || null;
    if (!s.actor) beginLoanStep(s);
    return s;
  }

  function buyDiscardCard(s, pid, cardId) {
    const p = byId(s, pid);
    if (!p || p.eliminated || s.step !== 'cards') return false;
    if (p.hand.length >= HAND_LIMIT) return false;
    const idx = s.discard.findIndex(c => c.id === cardId);
    if (idx < 0) return false;
    const card = s.discard[idx];
    const price = priceOf(card);
    if (p.cash < price) return false;
    s.discard.splice(idx, 1);
    p.hand.push(card);
    p.cash -= price;
    p.spent += price;
    s.bank.cash += price;
    log(s, p.name + ' bought ' + cardLabel(card) + ' from the Cards Space for ' + money(price) + '.', 'buy');
    return true;
  }

  function endCardTurn(s) {
    if (s.step !== 'cards') return s;
    s.queueIdx++;
    if (s.queueIdx < s.queue.length) {
      s.actor = s.queue[s.queueIdx];
    } else {
      beginLoanStep(s);
    }
    return s;
  }

  /* ---------- step 4: loans & elimination ---------- */
  function eliminate(s, pid, reason) {
    const p = byId(s, pid);
    if (!p || p.eliminated) return;
    p.eliminated = true;
    p.hand.forEach(c => s.discard.push(c));
    p.hand = [];
    s.loans.forEach(l => {
      if (l.borrowerId === pid) {
        const lender = l.lenderId === 'bank' ? null : byId(s, l.lenderId);
        log(s, (lender ? lender.name : 'The bank') + ' writes off ' + money(l.amount) + ' lent to ' + p.name + '.', 'bad');
      }
    });
    s.loans = s.loans.filter(l => l.borrowerId !== pid);
    log(s, p.name + ' is eliminated \u2014 ' + reason, 'bad');
  }

  function beginLoanStep(s) {
    s.step = 'loans';
    processDues(s);
    s.loanQueue = activePlayers(s).filter(p => p.cash < MIN_BID).map(p => p.id);
    s.loanIdx = 0;
    nextLoanCase(s);
    return s;
  }

  function processDues(s) {
    const due = s.loans.filter(l => l.dueRound <= s.round);
    due.forEach(l => {
      const b = byId(s, l.borrowerId);
      if (!b || b.eliminated) { s.loans = s.loans.filter(x => x !== l); return; }
      let need = l.amount;
      if (b.cash < need && b.gold > 0) {
        const goldNeeded = Math.ceil((need - b.cash) / s.goldPrice);
        const sell = Math.min(goldNeeded, b.gold);
        if (sell > 0) {
          b.gold -= sell; b.cash += sell * s.goldPrice; b.goldSold += sell;
          s.bank.cash -= sell * s.goldPrice;
          log(s, b.name + ' sold ' + sell + ' gold @ ' + money(s.goldPrice) + ' to service the loan.', 'gold');
        }
      }
      if (b.cash >= need) {
        b.cash -= need;
        if (l.lenderId === 'bank') s.bank.cash += need;
        else { const L = byId(s, l.lenderId); if (L) L.cash += need; }
        log(s, b.name + ' repaid ' + money(need) + ' to ' + (l.lenderId === 'bank' ? 'the bank' : byId(s, l.lenderId).name) + '.', 'loan');
        s.loans = s.loans.filter(x => x !== l);
      } else {
        s.loans = s.loans.filter(x => x !== l);
        eliminate(s, b.id, 'could not repay a ' + money(need) + ' loan.');
      }
    });
  }

  function nextLoanCase(s) {
    if (s.loanIdx >= s.loanQueue.length) { startMatch(s); return; }
    const pid = s.loanQueue[s.loanIdx];
    const p = byId(s, pid);
    if (!p || p.eliminated || p.cash >= MIN_BID) { s.loanIdx++; nextLoanCase(s); return; }
    s.step = 'loanRequest';
    s.actor = pid;
    s.loanPending = { borrower: pid, amount: null, lender: null, stage: 'request', rejected: [] };
  }

  function requestLoan(s, pid, amount, lenderId) {
    if (s.step !== 'loanRequest' || s.actor !== pid || !s.loanPending) return false;
    const p = byId(s, pid);
    amount = Math.round(amount);
    if (amount < MIN_BID - p.cash) return false;
    if (lenderId === 'bank') {
      if (amount > BANK_LOAN_CAP) return false;
      if (amount > s.bank.cash) return false;
      finalizeLoan(s, pid, amount, 'bank');
      return true;
    }
    const L = byId(s, lenderId);
    if (!L || L.eliminated || L.id === pid || L.cash < amount) return false;
    s.loanPending.amount = amount;
    s.loanPending.lender = lenderId;
    s.loanPending.stage = 'offer';
    s.step = 'loanOffer';
    s.actor = lenderId;
    return true;
  }

  function answerLoanOffer(s, lenderId, accept) {
    if (s.step !== 'loanOffer' || s.actor !== lenderId || !s.loanPending) return false;
    const lp = s.loanPending;
    if (accept) { finalizeLoan(s, lp.borrower, lp.amount, lenderId); return true; }
    lp.rejected.push(lenderId);
    lp.stage = 'request';
    lp.amount = null;
    lp.lender = null;
    s.step = 'loanRequest';
    s.actor = lp.borrower;
    const b = byId(s, lp.borrower);
    log(s, byId(s, lenderId).name + ' declined to lend ' + b.name + ' money.', 'loan');
    return true;
  }

  function finalizeLoan(s, borrowerId, amount, lenderId) {
    const b = byId(s, borrowerId);
    b.cash += amount;
    if (lenderId === 'bank') s.bank.cash -= amount;
    else { const L = byId(s, lenderId); L.cash -= amount; }
    s.loans.push({
      id: 'L' + (++s.logSeq) + '_' + s.round,
      borrowerId: borrowerId,
      lenderId: lenderId,
      amount: amount,
      takenRound: s.round,
      dueRound: s.round + 1
    });
    log(s, b.name + ' borrowed ' + money(amount) + ' from ' +
      (lenderId === 'bank' ? 'the bank' : byId(s, lenderId).name) +
      '. Repayable at the start of round ' + (s.round + 1) + '.', 'loan');
    s.loanPending = null;
    s.loanIdx++;
    nextLoanCase(s);
  }

  function declineLoan(s, pid) {
    if (s.step !== 'loanRequest' || s.actor !== pid) return false;
    s.loanPending = null;
    s.loanIdx++;
    eliminate(s, pid, 'had under ' + money(MIN_BID) + ' and took no loan.');
    nextLoanCase(s);
    return true;
  }

  function bankLoanMax(s, pid) {
    const p = byId(s, pid);
    if (!p) return 0;
    return Math.min(BANK_LOAN_CAP, s.bank.cash, Math.max(0, BANK_LOAN_CAP));
  }

  /* ---------- matches ---------- */
  function startMatch(s) {
    if (s.finished) return s;
    let pool = activePlayers(s).filter(p => p.cash >= MIN_BID).map(p => p.id);
    // a player whose hand is empty gets one card off the top (only reachable
    // when a round has more matches than a hand holds cards)
    pool.forEach(pid => {
      const p = byId(s, pid);
      if (p.hand.length === 0 && s.deck.length) p.hand.push(s.deck.pop());
    });
    pool = pool.filter(pid => byId(s, pid).hand.length > 0);
    if (pool.length < 2) { endRound(s, pool.length === 1 ? 'Only one player could still bid.' : 'Nobody could bid.'); return s; }

    s.matchIndex++;
    s.matchPlayers = pool;
    s.bids = {};
    s.plays = {};
    s.phase = 'bid';
    s.step = null;
    s.queue = pool.slice();
    s.queueIdx = 0;
    s.actor = s.queue[0];
    log(s, 'Match ' + s.matchIndex + ' of ' + s.matchesThisRound + ' \u2014 bids are open.', 'match');
    return s;
  }

  function placeBid(s, pid, amount) {
    if (s.phase !== 'bid') return false;
    if (s.matchPlayers.indexOf(pid) < 0) return false;
    if (s.bids[pid] != null) return false;
    const p = byId(s, pid);
    amount = Math.round(amount);
    if (!p) return false;
    if (!Number.isInteger(amount) || amount % 100 !== 0) {
      throw new Error('Bid must be a multiple of 100, got ' + amount);
    }
    if (amount < MIN_BID) throw new Error('Bid below minimum: ' + amount);
    if (amount > p.cash) throw new Error('Bid above cash: ' + amount + ' > ' + p.cash);
    s.bids[pid] = amount;
    advance(s, function () {
      s.phase = 'handReveal';
      s.actor = null;
      log(s, 'All bids locked. Hands revealed for this match.', 'match');
    });
    return true;
  }

  function advance(s, done) {
    s.queueIdx++;
    if (s.queueIdx < s.queue.length) s.actor = s.queue[s.queueIdx];
    else { s.actor = null; done(); }
  }

  function revealDone(s) {
    if (s.phase !== 'handReveal') return s;
    s.phase = 'select';
    s.queue = s.matchPlayers.slice();
    s.queueIdx = 0;
    s.actor = s.queue[0] || null;
    return s;
  }

  function playCard(s, pid, cardId) {
    if (s.phase !== 'select') return false;
    if (s.matchPlayers.indexOf(pid) < 0) return false;
    if (s.plays[pid]) return false;
    const p = byId(s, pid);
    const idx = p.hand.findIndex(c => c.id === cardId);
    if (idx < 0) return false;
    const card = p.hand.splice(idx, 1)[0];
    s.plays[pid] = card;
    advance(s, function () { resolveMatch(s); });
    return true;
  }

  function resolveMatch(s) {
    const entries = s.matchPlayers.map(pid => ({ pid: pid, card: s.plays[pid] }));
    entries.forEach(e => s.discard.push(e.card));
    s.plays = {};

    let pool = entries.slice();
    const cancelled = [];
    let winner = null;
    while (pool.length) {
      const maxR = Math.max.apply(null, pool.map(e => e.card.r));
      const top = pool.filter(e => e.card.r === maxR);
      if (top.length === 1) { winner = top[0]; break; }
      top.forEach(e => cancelled.push(e.pid));
      pool = pool.filter(e => e.card.r !== maxR);
    }

    const result = {
      entries: entries,
      cancelled: cancelled,
      winner: winner ? winner.pid : null,
      bids: Object.assign({}, s.bids),
      pot: 0,
      bonus: 0,
      returned: false
    };

    if (winner) {
      let pot = 0;
      s.matchPlayers.forEach(pid => {
        if (pid !== winner.pid) {
          const b = s.bids[pid] || 0;
          byId(s, pid).cash -= b;
          pot += b;
        }
      });
      const wb = s.bids[winner.pid] || 0;
      const bonus = wb > MIN_BID ? Math.floor(wb / 2) : 0;
      byId(s, winner.pid).cash += pot + bonus;
      byId(s, winner.pid).wins++;
      result.pot = pot;
      result.bonus = bonus;
      const wp = byId(s, winner.pid);
      log(s, wp.name + ' wins with ' + cardLabel(winner.card) +
        ' \u2014 collects ' + money(pot) + ' from bids' +
        (bonus ? ' + ' + money(bonus) + ' bank bonus' : '') + '.', 'win');
      if (cancelled.length) {
        log(s, 'Cancelled on a tie: ' + cancelled.map(id => byId(s, id).name).join(', ') + '.', 'tie');
      }
    } else {
      result.returned = true;
      log(s, 'Every player tied on the top rank \u2014 nobody wins, all bids returned.', 'tie');
    }

    s.lastMatch = result;
    s.phase = 'payout';
    s.actor = null;
    return result;
  }

  function payoutDone(s) {
    if (s.phase !== 'payout') return s;
    if (s.matchIndex >= s.matchesThisRound) endRound(s, null);
    else startMatch(s);
    return s;
  }

  /* ---------- round end ---------- */
  function endRound(s, reason) {
    s.phase = 'roundEnd';
    s.actor = null;
    activePlayers(s).forEach(p => {
      const hs = Math.max(HAND_REFILL, s.players.length);
      while (p.hand.length < hs && s.deck.length) p.hand.push(s.deck.pop());
    });
    s.roundEndInfo = {
      reason: reason || null,
      deckLeft: s.deck.length,
      standings: activePlayers(s).map(p => ({ id: p.id, name: p.name, cash: p.cash, gold: p.gold }))
        .sort((a, b) => (b.cash + b.gold * s.goldPrice) - (a.cash + a.gold * s.goldPrice))
    };
    log(s, 'Round ' + s.round + ' complete. Cards refilled. Draw deck: ' + s.deck.length + '.', 'round');
    return s;
  }

  function nextRound(s) {
    if (s.phase !== 'roundEnd') return s;
    if (s.round >= s.totalRounds) { finalPhase(s); return s; }
    if (s.deck.length === 0 || activePlayers(s).length < 2) { finalPhase(s); return s; }
    s.round++;
    startRound(s);
    return s;
  }

  /* ---------- final gold sale & results ---------- */
  function finalPhase(s) {
    s.phase = 'finalSell';
    s.step = 'finalSell';
    s.queue = activePlayers(s).map(p => p.id);
    s.queueIdx = 0;
    s.actor = s.queue[0] || null;
    log(s, 'The draw deck is empty. Final gold sale at ' + money(s.goldPrice) + ' per biscuit.', 'gold');
    if (!s.actor) finishGame(s);
    return s;
  }

  function sellFinal(s, pid, qty) {
    if (s.step !== 'finalSell' || s.actor !== pid) return false;
    const p = byId(s, pid);
    qty = Math.floor(qty);
    if (qty < 0 || qty > p.gold) return false;
    if (qty > 0) {
      const gain = qty * s.goldPrice;
      p.gold -= qty; p.cash += gain; p.goldSold += qty;
      log(s, p.name + ' sold ' + qty + ' gold in the final sale for ' + money(gain) + '.', 'gold');
    }
    s.queueIdx++;
    if (s.queueIdx < s.queue.length) s.actor = s.queue[s.queueIdx];
    else { s.actor = null; finishGame(s); }
    return true;
  }

  function finishGame(s) {
    s.finished = true;
    s.phase = 'gameEnd';
    s.actor = null;
    s.players.forEach(p => { p.hand.forEach(c => s.discard.push(c)); p.hand = []; });
    const rows = s.players.map(p => ({
      id: p.id,
      name: p.name,
      eliminated: p.eliminated,
      cash: p.cash,
      gold: p.gold,
      goldSold: p.goldSold,
      netWorth: p.cash + p.gold * s.goldPrice,
      wins: p.wins
    })).sort((a, b) => {
      if (a.eliminated !== b.eliminated) return a.eliminated ? 1 : -1;
      return b.cash - a.cash;
    });
    rows.forEach((r, i) => { r.rank = i + 1; });
    s.results = { rows: rows, goldPrice: s.goldPrice, rounds: s.round };
    log(s, 'Game over. ' + rows[0].name + ' takes the table with ' + money(rows[0].cash) + ' cash.', 'good');
    return s;
  }

  /* ---------- queries used by the UI ---------- */
  function phaseLabel(s) {
    if (s.phase === 'gameEnd') return 'Game Over';
    if (s.phase === 'roundEnd') return 'Round Complete';
    if (s.phase === 'roundStart') {
      return s.step === 'gold' ? 'Round Start \u2014 Gold Market'
        : s.step === 'cards' ? 'Round Start \u2014 Cards Space'
        : 'Round Start \u2014 Loans';
    }
    if (s.phase === 'bid') return 'Bidding';
    if (s.phase === 'handReveal') return 'Hand Reveal';
    if (s.phase === 'select') return 'Select Card';
    if (s.phase === 'payout') return 'Reveal \u2014 Payout';
    if (s.phase === 'finalSell') return 'Final Gold Sale';
    return 'Table';
  }

  function legalBidRange(s, pid) {
    const p = byId(s, pid);
    if (!p) return { min: MIN_BID, max: MIN_BID };
    return { min: MIN_BID, max: Math.max(MIN_BID, Math.floor(p.cash)) };
  }

  function loanOptions(s, pid) {
    const p = byId(s, pid);
    const out = [{ id: 'bank', name: 'The Bank', max: bankLoanMax(s, pid) }];
    activePlayers(s).forEach(o => {
      if (o.id !== pid && o.cash >= MIN_BID - p.cash) out.push({ id: o.id, name: o.name, max: o.cash });
    });
    return out;
  }

  function netWorth(s, p) { return p.cash + p.gold * s.goldPrice; }

  return {
    RANKS: RANKS, RANK_LABEL: RANK_LABEL, SUITS: SUITS, CARD_PRICE: CARD_PRICE,
    MIN_BID: MIN_BID, HAND_REFILL: HAND_REFILL, HAND_LIMIT: HAND_LIMIT,
    BANK_LOAN_CAP: BANK_LOAN_CAP, GOLD_MIN: GOLD_MIN, GOLD_MAX: GOLD_MAX,
    newGame: newGame,
    startRound: startRound,
    buyGold: buyGold, sellGold: sellGold, endGoldTurn: endGoldTurn,
    buyDiscardCard: buyDiscardCard, endCardTurn: endCardTurn,
    requestLoan: requestLoan, answerLoanOffer: answerLoanOffer, declineLoan: declineLoan,
    loanOptions: loanOptions, bankLoanMax: bankLoanMax,
    placeBid: placeBid, revealDone: revealDone, playCard: playCard,
    payoutDone: payoutDone, nextRound: nextRound,
    sellFinal: sellFinal, finishGame: finishGame,
    activePlayers: activePlayers, byId: byId, phaseLabel: phaseLabel,
    cardLabel: cardLabel, cardName: cardName, priceOf: priceOf,
    legalBidRange: legalBidRange, netWorth: netWorth,
    money: money, log: log
  };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = Engine;
